"use strict";
(function() {
    try {
        var a = require("@marcom/ac-analytics");
        a.createBasicObserverSuite()
    } catch (e) {}
})();