! function() {
    function e(t, r, i) {
        function n(a, o) {
            if (!r[a]) {
                if (!t[a]) {
                    var l = "function" == typeof require && require;
                    if (!o && l) return l(a, !0);
                    if (s) return s(a, !0);
                    var c = new Error("Cannot find module '" + a + "'");
                    throw c.code = "MODULE_NOT_FOUND", c
                }
                var u = r[a] = {
                    exports: {}
                };
                t[a][0].call(u.exports, function(e) {
                    var r = t[a][1][e];
                    return n(r ? r : e)
                }, u, u.exports, e, t, r, i)
            }
            return r[a].exports
        }
        for (var s = "function" == typeof require && require, a = 0; a < i.length; a++) n(i[a]);
        return n
    }
    return e
}()({
    1: [function(e, t, r) {
        "use strict";

        function i() {
            this._createElemnts(), this._bindEvents()
        }
        var n = i.prototype;
        n._bindEvents = function() {
            this._onResize = this._resize.bind(this)
        }, n._createElemnts = function() {
            this.span = document.createElement("span");
            var e = this.span.style;
            e.visibility = "hidden", e.position = "absolute", e.top = "0", e.bottom = "0", e.zIndex = "-1", this.span.innerHTML = "&nbsp;", this.iframe = document.createElement("iframe");
            var t = this.iframe.style;
            t.position = "absolute", t.top = "0", t.left = "0", t.width = "100%", t.height = "100%", this.span.appendChild(this.iframe), document.body.appendChild(this.span)
        }, n.detect = function(e) {
            this.originalSize = e || 17, this.currentSize = parseFloat(window.getComputedStyle(this.span)["font-size"]), this.currentSize > this.originalSize && this._onResize(), this.isDetecting || (this.iframe.contentWindow.addEventListener("resize", this._onResize), this.isDetecting = !0)
        }, n._resize = function(e) {
            this.currentSize = parseFloat(window.getComputedStyle(this.span)["font-size"]), this.originalSize < this.currentSize ? document.documentElement.classList.add("text-zoom") : document.documentElement.classList.remove("text-zoom"), window.dispatchEvent(new Event("resize"))
        }, n.remove = function() {
            this.isDetecting && (this.iframe.contentWindow.removeEventListener("resize", this._onResize), this.isDetecting = !1)
        }, n.destroy = function() {
            this.remove(), this.span && this.span.parentElement && this.span.parentElement.removeChild(this.span), this.span = null, this.iframe = null
        }, t.exports = new i
    }, {}],
    2: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = e("@marcom/ac-scroll-container").ScrollContainer,
            a = {
                componentName: "chapternav",
                scrollEasing: "ease-out",
                scrollDuration: .4,
                usePaddles: !0
            },
            o = function() {
                function e(t, r) {
                    return i(this, e), this.el = t, r = Object.assign({}, a, r), this.options = {
                        componentName: r.componentName,
                        itemsSelector: r.itemsSelector || "." + r.componentName + "-items",
                        itemSelector: r.itemSelector || "." + r.componentName + "-link",
                        itemLabelSelector: r.itemLabelSelector || "." + r.componentName + "-label",
                        itemNewSelector: r.itemNewSelector || "." + r.componentName + "-new",
                        leftPaddleSelector: r.leftPaddleSelector || "." + r.componentName + "-paddle-left",
                        rightPaddleSelector: r.rightPaddleSelector || "." + r.componentName + "-paddle-right",
                        tallClass: r.tallClass || r.componentName + "-tall",
                        scrollEasing: r.scrollEasing,
                        scrollDuration: r.scrollDuration,
                        usePaddles: r.usePaddles
                    }, this.setChapternavTall(this.isChapternavTall()), new s(this.el, this.options)
                }
                return n(e, [{
                    key: "isChapternavTall",
                    value: function t() {
                        var e = this,
                            r = this.el.querySelectorAll(this.options.itemSelector),
                            t = !1;
                        return r.forEach(function(r) {
                            var i = r.querySelector(e.options.itemLabelSelector),
                                n = !!r.querySelector(e.options.itemNewSelector),
                                s = i.getElementsByTagName("BR").length > 0;
                            n && s && (t = !0)
                        }), t
                    }
                }, {
                    key: "setChapternavTall",
                    value: function(e) {
                        e === !0 ? this.el.classList.add(this.options.tallClass) : this.el.classList.remove(this.options.tallClass)
                    }
                }]), e
            }();
        t.exports = o
    }, {
        "@marcom/ac-scroll-container": 24
    }],
    3: [function(e, t, r) {
        "use strict";
        var i = e("./ChapterNav"),
            n = document.getElementById("chapternav");
        n && (t.exports = new i(n))
    }, {
        "./ChapterNav": 2
    }],
    4: [function(e, t, r) {
        "use strict";
        t.exports = {
            EventEmitterMicro: e("./ac-event-emitter-micro/EventEmitterMicro")
        }
    }, {
        "./ac-event-emitter-micro/EventEmitterMicro": 5
    }],
    5: [function(e, t, r) {
        "use strict";

        function i() {
            this._events = {}
        }
        var n = i.prototype;
        n.on = function(e, t) {
            this._events[e] = this._events[e] || [], this._events[e].unshift(t)
        }, n.once = function(e, t) {
            function r(n) {
                i.off(e, r), void 0 !== n ? t(n) : t()
            }
            var i = this;
            this.on(e, r)
        }, n.off = function(e, t) {
            if (this.has(e)) {
                if (1 === arguments.length) return this._events[e] = null, void delete this._events[e];
                var r = this._events[e].indexOf(t);
                r !== -1 && this._events[e].splice(r, 1)
            }
        }, n.trigger = function(e, t) {
            if (this.has(e))
                for (var r = this._events[e].length - 1; r >= 0; r--) void 0 !== t ? this._events[e][r](t) : this._events[e][r]()
        }, n.has = function(e) {
            return e in this._events != !1 && 0 !== this._events[e].length
        }, n.destroy = function() {
            for (var e in this._events) this._events[e] = null;
            this._events = null
        }, t.exports = i
    }, {}],
    6: [function(e, t, r) {
        "use strict";
        var i = e("@marcom/ac-shared-instance").SharedInstance,
            n = "ac-raf-emitter-id-generator:sharedRAFEmitterIDGeneratorInstance",
            s = "1.0.3",
            a = function() {
                this._currentID = 0
            };
        a.prototype.getNewID = function() {
            return this._currentID++, "raf:" + this._currentID
        }, t.exports = i.share(n, s, a)
    }, {
        "@marcom/ac-shared-instance": 25
    }],
    7: [function(e, t, r) {
        "use strict";
        t.exports = {
            majorVersionNumber: "3.x"
        }
    }, {}],
    8: [function(e, t, r) {
        "use strict";

        function i(e) {
            e = e || {}, s.call(this), this.id = o.getNewID(), this.executor = e.executor || a, this._reset(), this._willRun = !1, this._didDestroy = !1
        }
        var n, s = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            a = e("./sharedRAFExecutorInstance"),
            o = e("./sharedRAFEmitterIDGeneratorInstance");
        n = i.prototype = Object.create(s.prototype), n.run = function() {
            return this._willRun || (this._willRun = !0), this._subscribe()
        }, n.cancel = function() {
            this._unsubscribe(), this._willRun && (this._willRun = !1), this._reset()
        }, n.destroy = function() {
            var e = this.willRun();
            return this.cancel(), this.executor = null, s.prototype.destroy.call(this), this._didDestroy = !0, e
        }, n.willRun = function() {
            return this._willRun
        }, n.isRunning = function() {
            return this._isRunning
        }, n._subscribe = function() {
            return this.executor.subscribe(this)
        }, n._unsubscribe = function() {
            return this.executor.unsubscribe(this)
        }, n._onAnimationFrameStart = function(e) {
            this._isRunning = !0, this._willRun = !1, this._didEmitFrameData || (this._didEmitFrameData = !0, this.trigger("start", e))
        }, n._onAnimationFrameEnd = function(e) {
            this._willRun || (this.trigger("stop", e), this._reset())
        }, n._reset = function() {
            this._didEmitFrameData = !1, this._isRunning = !1
        }, t.exports = i
    }, {
        "./sharedRAFEmitterIDGeneratorInstance": 16,
        "./sharedRAFExecutorInstance": 17,
        "@marcom/ac-event-emitter-micro": 4
    }],
    9: [function(e, t, r) {
        "use strict";

        function i(e) {
            e = e || {}, this._reset(), this.updatePhases(), this.eventEmitter = new s, this._willRun = !1, this._totalSubscribeCount = -1, this._requestAnimationFrame = window.requestAnimationFrame, this._cancelAnimationFrame = window.cancelAnimationFrame, this._boundOnAnimationFrame = this._onAnimationFrame.bind(this), this._boundOnExternalAnimationFrame = this._onExternalAnimationFrame.bind(this)
        }
        var n, s = e("@marcom/ac-event-emitter-micro/EventEmitterMicro");
        n = i.prototype, n.frameRequestedPhase = "requested", n.startPhase = "start", n.runPhases = ["update", "external", "draw"], n.endPhase = "end", n.disabledPhase = "disabled", n.beforePhaseEventPrefix = "before:", n.afterPhaseEventPrefix = "after:", n.subscribe = function(e, t) {
            return this._totalSubscribeCount++, this._nextFrameSubscribers[e.id] || (t ? this._nextFrameSubscribersOrder.unshift(e.id) : this._nextFrameSubscribersOrder.push(e.id), this._nextFrameSubscribers[e.id] = e, this._nextFrameSubscriberArrayLength++, this._nextFrameSubscriberCount++, this._run()), this._totalSubscribeCount
        }, n.subscribeImmediate = function(e, t) {
            return this._totalSubscribeCount++, this._subscribers[e.id] || (t ? this._subscribersOrder.splice(this._currentSubscriberIndex + 1, 0, e.id) : this._subscribersOrder.unshift(e.id), this._subscribers[e.id] = e, this._subscriberArrayLength++, this._subscriberCount++), this._totalSubscribeCount
        }, n.unsubscribe = function(e) {
            return !!this._nextFrameSubscribers[e.id] && (this._nextFrameSubscribers[e.id] = null, this._nextFrameSubscriberCount--, 0 === this._nextFrameSubscriberCount && this._cancel(), !0)
        }, n.getSubscribeID = function() {
            return this._totalSubscribeCount += 1
        }, n.destroy = function() {
            var e = this._cancel();
            return this.eventEmitter.destroy(), this.eventEmitter = null, this.phases = null, this._subscribers = null, this._subscribersOrder = null, this._nextFrameSubscribers = null, this._nextFrameSubscribersOrder = null, this._rafData = null, this._boundOnAnimationFrame = null, this._onExternalAnimationFrame = null, e
        }, n.useExternalAnimationFrame = function(e) {
            if ("boolean" == typeof e) {
                var t = this._isUsingExternalAnimationFrame;
                return e && this._animationFrame && (this._cancelAnimationFrame.call(window, this._animationFrame), this._animationFrame = null), !this._willRun || e || this._animationFrame || (this._animationFrame = this._requestAnimationFrame.call(window, this._boundOnAnimationFrame)), this._isUsingExternalAnimationFrame = e, e ? this._boundOnExternalAnimationFrame : t || !1
            }
        }, n.updatePhases = function() {
            this.phases || (this.phases = []), this.phases.length = 0, this.phases.push(this.frameRequestedPhase), this.phases.push(this.startPhase), Array.prototype.push.apply(this.phases, this.runPhases), this.phases.push(this.endPhase), this._runPhasesLength = this.runPhases.length, this._phasesLength = this.phases.length
        }, n._run = function() {
            if (!this._willRun) return this._willRun = !0, 0 === this.lastFrameTime && (this.lastFrameTime = performance.now()), this._animationFrameActive = !0, this._isUsingExternalAnimationFrame || (this._animationFrame = this._requestAnimationFrame.call(window, this._boundOnAnimationFrame)), this.phase === this.disabledPhase && (this.phaseIndex = 0, this.phase = this.phases[this.phaseIndex]), !0
        }, n._cancel = function() {
            var e = !1;
            return this._animationFrameActive && (this._animationFrame && (this._cancelAnimationFrame.call(window, this._animationFrame), this._animationFrame = null), this._animationFrameActive = !1, this._willRun = !1, e = !0), this._isRunning || this._reset(), e
        }, n._onAnimationFrame = function(e) {
            for (this._subscribers = this._nextFrameSubscribers, this._subscribersOrder = this._nextFrameSubscribersOrder, this._subscriberArrayLength = this._nextFrameSubscriberArrayLength, this._subscriberCount = this._nextFrameSubscriberCount, this._nextFrameSubscribers = {}, this._nextFrameSubscribersOrder = [], this._nextFrameSubscriberArrayLength = 0, this._nextFrameSubscriberCount = 0, this.phaseIndex = 0, this.phase = this.phases[this.phaseIndex], this._isRunning = !0, this._willRun = !1, this._didRequestNextRAF = !1, this._rafData.delta = e - this.lastFrameTime, this.lastFrameTime = e, this._rafData.fps = 0, this._rafData.delta >= 1e3 && (this._rafData.delta = 0), 0 !== this._rafData.delta && (this._rafData.fps = 1e3 / this._rafData.delta), this._rafData.time = e, this._rafData.naturalFps = this._rafData.fps, this._rafData.timeNow = Date.now(), this.phaseIndex++, this.phase = this.phases[this.phaseIndex], this.eventEmitter.trigger(this.beforePhaseEventPrefix + this.phase), this._currentSubscriberIndex = 0; this._currentSubscriberIndex < this._subscriberArrayLength; this._currentSubscriberIndex++) null !== this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]] && this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]]._didDestroy === !1 && this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]]._onAnimationFrameStart(this._rafData);
            for (this.eventEmitter.trigger(this.afterPhaseEventPrefix + this.phase), this._runPhaseIndex = 0; this._runPhaseIndex < this._runPhasesLength; this._runPhaseIndex++) {
                for (this.phaseIndex++, this.phase = this.phases[this.phaseIndex], this.eventEmitter.trigger(this.beforePhaseEventPrefix + this.phase), this._currentSubscriberIndex = 0; this._currentSubscriberIndex < this._subscriberArrayLength; this._currentSubscriberIndex++) null !== this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]] && this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]]._didDestroy === !1 && this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]].trigger(this.phase, this._rafData);
                this.eventEmitter.trigger(this.afterPhaseEventPrefix + this.phase)
            }
            for (this.phaseIndex++, this.phase = this.phases[this.phaseIndex], this.eventEmitter.trigger(this.beforePhaseEventPrefix + this.phase), this._currentSubscriberIndex = 0; this._currentSubscriberIndex < this._subscriberArrayLength; this._currentSubscriberIndex++) null !== this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]] && this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]]._didDestroy === !1 && this._subscribers[this._subscribersOrder[this._currentSubscriberIndex]]._onAnimationFrameEnd(this._rafData);
            this.eventEmitter.trigger(this.afterPhaseEventPrefix + this.phase), this._willRun ? (this.phaseIndex = 0, this.phaseIndex = this.phases[this.phaseIndex]) : this._reset()
        }, n._onExternalAnimationFrame = function(e) {
            this._isUsingExternalAnimationFrame && this._onAnimationFrame(e)
        }, n._reset = function() {
            this._rafData || (this._rafData = {}), this._rafData.time = 0, this._rafData.delta = 0, this._rafData.fps = 0, this._rafData.naturalFps = 0, this._rafData.timeNow = 0, this._subscribers = {}, this._subscribersOrder = [], this._currentSubscriberIndex = -1, this._subscriberArrayLength = 0, this._subscriberCount = 0, this._nextFrameSubscribers = {}, this._nextFrameSubscribersOrder = [], this._nextFrameSubscriberArrayLength = 0, this._nextFrameSubscriberCount = 0, this._didEmitFrameData = !1, this._animationFrame = null, this._animationFrameActive = !1, this._isRunning = !1, this._shouldReset = !1, this.lastFrameTime = 0, this._runPhaseIndex = -1, this.phaseIndex = -1, this.phase = this.disabledPhase
        }, t.exports = i
    }, {
        "@marcom/ac-event-emitter-micro/EventEmitterMicro": 5
    }],
    10: [function(e, t, r) {
        "use strict";
        var i = e("./SingleCallRAFEmitter"),
            n = function(e) {
                this.phase = e, this.rafEmitter = new i, this._cachePhaseIndex(), this.requestAnimationFrame = this.requestAnimationFrame.bind(this), this.cancelAnimationFrame = this.cancelAnimationFrame.bind(this), this._onBeforeRAFExecutorStart = this._onBeforeRAFExecutorStart.bind(this), this._onBeforeRAFExecutorPhase = this._onBeforeRAFExecutorPhase.bind(this), this._onAfterRAFExecutorPhase = this._onAfterRAFExecutorPhase.bind(this), this.rafEmitter.on(this.phase, this._onRAFExecuted.bind(this)), this.rafEmitter.executor.eventEmitter.on("before:start", this._onBeforeRAFExecutorStart), this.rafEmitter.executor.eventEmitter.on("before:" + this.phase, this._onBeforeRAFExecutorPhase), this.rafEmitter.executor.eventEmitter.on("after:" + this.phase, this._onAfterRAFExecutorPhase), this._frameCallbacks = [], this._currentFrameCallbacks = [], this._nextFrameCallbacks = [], this._phaseActive = !1, this._currentFrameID = -1, this._cancelFrameIdx = -1, this._frameCallbackLength = 0, this._currentFrameCallbacksLength = 0, this._nextFrameCallbacksLength = 0, this._frameCallbackIteration = 0
            },
            s = n.prototype;
        s.requestAnimationFrame = function(e, t) {
            return t === !0 && this.rafEmitter.executor.phaseIndex > 0 && this.rafEmitter.executor.phaseIndex <= this.phaseIndex ? this._phaseActive ? (this._currentFrameID = this.rafEmitter.executor.subscribeImmediate(this.rafEmitter, !0), this._frameCallbacks.push(this._currentFrameID, e), this._frameCallbackLength += 2) : (this._currentFrameID = this.rafEmitter.executor.subscribeImmediate(this.rafEmitter, !1), this._currentFrameCallbacks.push(this._currentFrameID, e), this._currentFrameCallbacksLength += 2) : (this._currentFrameID = this.rafEmitter.run(), this._nextFrameCallbacks.push(this._currentFrameID, e), this._nextFrameCallbacksLength += 2), this._currentFrameID
        }, s.cancelAnimationFrame = function(e) {
            this._cancelFrameIdx = this._nextFrameCallbacks.indexOf(e), this._cancelFrameIdx > -1 ? this._cancelNextAnimationFrame() : (this._cancelFrameIdx = this._currentFrameCallbacks.indexOf(e), this._cancelFrameIdx > -1 ? this._cancelCurrentAnimationFrame() : (this._cancelFrameIdx = this._frameCallbacks.indexOf(e), this._cancelFrameIdx > -1 && this._cancelRunningAnimationFrame()))
        }, s._onRAFExecuted = function(e) {
            for (this._frameCallbackIteration = 0; this._frameCallbackIteration < this._frameCallbackLength; this._frameCallbackIteration += 2) this._frameCallbacks[this._frameCallbackIteration + 1](e.time, e);
            this._frameCallbacks.length = 0, this._frameCallbackLength = 0
        }, s._onBeforeRAFExecutorStart = function() {
            Array.prototype.push.apply(this._currentFrameCallbacks, this._nextFrameCallbacks.splice(0, this._nextFrameCallbacksLength)), this._currentFrameCallbacksLength = this._nextFrameCallbacksLength, this._nextFrameCallbacks.length = 0, this._nextFrameCallbacksLength = 0
        }, s._onBeforeRAFExecutorPhase = function() {
            this._phaseActive = !0, Array.prototype.push.apply(this._frameCallbacks, this._currentFrameCallbacks.splice(0, this._currentFrameCallbacksLength)), this._frameCallbackLength = this._currentFrameCallbacksLength, this._currentFrameCallbacks.length = 0, this._currentFrameCallbacksLength = 0
        }, s._onAfterRAFExecutorPhase = function() {
            this._phaseActive = !1
        }, s._cachePhaseIndex = function() {
            this.phaseIndex = this.rafEmitter.executor.phases.indexOf(this.phase)
        }, s._cancelRunningAnimationFrame = function() {
            this._frameCallbacks.splice(this._cancelFrameIdx, 2), this._frameCallbackLength -= 2
        }, s._cancelCurrentAnimationFrame = function() {
            this._currentFrameCallbacks.splice(this._cancelFrameIdx, 2), this._currentFrameCallbacksLength -= 2
        }, s._cancelNextAnimationFrame = function() {
            this._nextFrameCallbacks.splice(this._cancelFrameIdx, 2), this._nextFrameCallbacksLength -= 2, 0 === this._nextFrameCallbacksLength && this.rafEmitter.cancel()
        }, t.exports = n
    }, {
        "./SingleCallRAFEmitter": 12
    }],
    11: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterface"),
            n = function() {
                this.events = {}
            },
            s = n.prototype;
        s.requestAnimationFrame = function(e) {
            return this.events[e] || (this.events[e] = new i(e)), this.events[e].requestAnimationFrame
        }, s.cancelAnimationFrame = function(e) {
            return this.events[e] || (this.events[e] = new i(e)), this.events[e].cancelAnimationFrame
        }, t.exports = new n
    }, {
        "./RAFInterface": 10
    }],
    12: [function(e, t, r) {
        "use strict";
        var i = e("./RAFEmitter"),
            n = function(e) {
                i.call(this, e)
            },
            s = n.prototype = Object.create(i.prototype);
        s._subscribe = function() {
            return this.executor.subscribe(this, !0)
        }, t.exports = n
    }, {
        "./RAFEmitter": 8
    }],
    13: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterfaceController");
        t.exports = i.cancelAnimationFrame("update")
    }, {
        "./RAFInterfaceController": 11
    }],
    14: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterfaceController");
        t.exports = i.requestAnimationFrame("draw")
    }, {
        "./RAFInterfaceController": 11
    }],
    15: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterfaceController");
        t.exports = i.requestAnimationFrame("external")
    }, {
        "./RAFInterfaceController": 11
    }],
    16: [function(e, t, r) {
        "use strict";
        var i = e("@marcom/ac-shared-instance").SharedInstance,
            n = e("../.release-info.js").majorVersionNumber,
            s = function() {
                this._currentID = 0
            };
        s.prototype.getNewID = function() {
            return this._currentID++, "raf:" + this._currentID
        }, t.exports = i.share("@marcom/ac-raf-emitter/sharedRAFEmitterIDGeneratorInstance", n, s)
    }, {
        "../.release-info.js": 7,
        "@marcom/ac-shared-instance": 25
    }],
    17: [function(e, t, r) {
        "use strict";
        var i = e("@marcom/ac-shared-instance").SharedInstance,
            n = e("../.release-info.js").majorVersionNumber,
            s = e("./RAFExecutor");
        t.exports = i.share("@marcom/ac-raf-emitter/sharedRAFExecutorInstance", n, s)
    }, {
        "../.release-info.js": 7,
        "./RAFExecutor": 9,
        "@marcom/ac-shared-instance": 25
    }],
    18: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterfaceController");
        t.exports = i.requestAnimationFrame("update")
    }, {
        "./RAFInterfaceController": 11
    }],
    19: [function(e, t, r) {
        "use strict";

        function i(e) {
            e = e || {}, this._reset(), this._willRun = !1, this._totalSubscribeCount = -1, this._requestAnimationFrame = window.requestAnimationFrame, this._cancelAnimationFrame = window.cancelAnimationFrame, this._boundOnAnimationFrame = this._onAnimationFrame.bind(this), this._boundOnExternalAnimationFrame = this._onExternalAnimationFrame.bind(this)
        }
        e("@marcom/ac-polyfills/performance/now");
        var n;
        n = i.prototype, n.subscribe = function(e, t) {
            return this._totalSubscribeCount++, this._nextFrameSubscribers[e.id] || (t ? this._nextFrameSubscribersOrder.unshift(e.id) : this._nextFrameSubscribersOrder.push(e.id), this._nextFrameSubscribers[e.id] = e, this._nextFrameSubscriberArrayLength++, this._nextFrameSubscriberCount++, this._run()), this._totalSubscribeCount
        }, n.unsubscribe = function(e) {
            return !!this._nextFrameSubscribers[e.id] && (this._nextFrameSubscribers[e.id] = null, this._nextFrameSubscriberCount--, 0 === this._nextFrameSubscriberCount && this._cancel(), !0)
        }, n.trigger = function(e, t) {
            var r;
            for (r = 0; r < this._subscriberArrayLength; r++) null !== this._subscribers[this._subscribersOrder[r]] && this._subscribers[this._subscribersOrder[r]]._didDestroy === !1 && this._subscribers[this._subscribersOrder[r]].trigger(e, t)
        }, n.destroy = function() {
            var e = this._cancel();
            return this._subscribers = null, this._subscribersOrder = null, this._nextFrameSubscribers = null, this._nextFrameSubscribersOrder = null, this._rafData = null, this._boundOnAnimationFrame = null, this._onExternalAnimationFrame = null, e
        }, n.useExternalAnimationFrame = function(e) {
            if ("boolean" == typeof e) {
                var t = this._isUsingExternalAnimationFrame;
                return e && this._animationFrame && (this._cancelAnimationFrame.call(window, this._animationFrame), this._animationFrame = null), !this._willRun || e || this._animationFrame || (this._animationFrame = this._requestAnimationFrame.call(window, this._boundOnAnimationFrame)), this._isUsingExternalAnimationFrame = e, e ? this._boundOnExternalAnimationFrame : t || !1
            }
        }, n._run = function() {
            if (!this._willRun) return this._willRun = !0, 0 === this.lastFrameTime && (this.lastFrameTime = performance.now()), this._animationFrameActive = !0, this._isUsingExternalAnimationFrame || (this._animationFrame = this._requestAnimationFrame.call(window, this._boundOnAnimationFrame)), !0
        }, n._cancel = function() {
            var e = !1;
            return this._animationFrameActive && (this._animationFrame && (this._cancelAnimationFrame.call(window, this._animationFrame), this._animationFrame = null), this._animationFrameActive = !1, this._willRun = !1, e = !0), this._isRunning || this._reset(), e
        }, n._onSubscribersAnimationFrameStart = function(e) {
            var t;
            for (t = 0; t < this._subscriberArrayLength; t++) null !== this._subscribers[this._subscribersOrder[t]] && this._subscribers[this._subscribersOrder[t]]._didDestroy === !1 && this._subscribers[this._subscribersOrder[t]]._onAnimationFrameStart(e)
        }, n._onSubscribersAnimationFrameEnd = function(e) {
            var t;
            for (t = 0; t < this._subscriberArrayLength; t++) null !== this._subscribers[this._subscribersOrder[t]] && this._subscribers[this._subscribersOrder[t]]._didDestroy === !1 && this._subscribers[this._subscribersOrder[t]]._onAnimationFrameEnd(e)
        }, n._onAnimationFrame = function(e) {
            this._subscribers = this._nextFrameSubscribers, this._subscribersOrder = this._nextFrameSubscribersOrder, this._subscriberArrayLength = this._nextFrameSubscriberArrayLength, this._subscriberCount = this._nextFrameSubscriberCount, this._nextFrameSubscribers = {}, this._nextFrameSubscribersOrder = [], this._nextFrameSubscriberArrayLength = 0, this._nextFrameSubscriberCount = 0, this._isRunning = !0, this._willRun = !1, this._didRequestNextRAF = !1, this._rafData.delta = e - this.lastFrameTime, this.lastFrameTime = e, this._rafData.fps = 0, this._rafData.delta >= 1e3 && (this._rafData.delta = 0), 0 !== this._rafData.delta && (this._rafData.fps = 1e3 / this._rafData.delta), this._rafData.time = e, this._rafData.naturalFps = this._rafData.fps, this._rafData.timeNow = Date.now(), this._onSubscribersAnimationFrameStart(this._rafData), this.trigger("update", this._rafData), this.trigger("external", this._rafData), this.trigger("draw", this._rafData), this._onSubscribersAnimationFrameEnd(this._rafData), this._willRun || this._reset()
        }, n._onExternalAnimationFrame = function(e) {
            this._isUsingExternalAnimationFrame && this._onAnimationFrame(e)
        }, n._reset = function() {
            this._rafData = {
                time: 0,
                delta: 0,
                fps: 0,
                naturalFps: 0,
                timeNow: 0
            }, this._subscribers = {}, this._subscribersOrder = [], this._subscriberArrayLength = 0, this._subscriberCount = 0, this._nextFrameSubscribers = {}, this._nextFrameSubscribersOrder = [], this._nextFrameSubscriberArrayLength = 0, this._nextFrameSubscriberCount = 0, this._didEmitFrameData = !1, this._animationFrame = null, this._animationFrameActive = !1, this._isRunning = !1, this._shouldReset = !1, this.lastFrameTime = 0
        }, t.exports = i
    }, {
        "@marcom/ac-polyfills/performance/now": void 0
    }],
    20: [function(e, t, r) {
        "use strict";
        var i = e("@marcom/ac-shared-instance").SharedInstance,
            n = "ac-raf-executor:sharedRAFExecutorInstance",
            s = "2.0.1",
            a = e("./RAFExecutor");
        t.exports = i.share(n, s, a)
    }, {
        "./RAFExecutor": 19,
        "@marcom/ac-shared-instance": 25
    }],
    21: [function(e, t, r) {
        "use strict";
        var i = {};
        i.easeInCubic = "cubic-bezier(0.42, 0.0, 1.0, 1.0)", i.easeOutCubic = "cubic-bezier(0.0, 0.0, 0.58, 1.0)", i.easeInOutCubic = "cubic-bezier(0.42, 0.0, 0.58, 1.0)", i.easeInCirc = "cubic-bezier(0.600, 0.040, 0.980, 0.335)", i.easeOutCirc = "cubic-bezier(0.075, 0.820, 0.165, 1.000)", i.easeInOutCirc = "cubic-bezier(0.785, 0.135, 0.150, 0.860)", i.easeInExpo = "cubic-bezier(0.950, 0.050, 0.795, 0.035)", i.easeOutExpo = "cubic-bezier(0.190, 1.000, 0.220, 1.000)", i.easeInOutExpo = "cubic-bezier(1.000, 0.000, 0.000, 1.000)", i.easeInQuad = "cubic-bezier(0.550, 0.085, 0.680, 0.530)", i.easeOutQuad = "cubic-bezier(0.250, 0.460, 0.450, 0.940)", i.easeInOutQuad = "cubic-bezier(0.455, 0.030, 0.515, 0.955)", i.easeInQuart = "cubic-bezier(0.895, 0.030, 0.685, 0.220)", i.easeOutQuart = "cubic-bezier(0.165, 0.840, 0.440, 1.000)", i.easeInOutQuart = "cubic-bezier(0.770, 0.000, 0.175, 1.000)", i.easeInQuint = "cubic-bezier(0.755, 0.050, 0.855, 0.060)", i.easeOutQuint = "cubic-bezier(0.230, 1.000, 0.320, 1.000)", i.easeInOutQuint = "cubic-bezier(0.860, 0.000, 0.070, 1.000)", i.easeInSine = "cubic-bezier(0.470, 0.000, 0.745, 0.715)", i.easeOutSine = "cubic-bezier(0.390, 0.575, 0.565, 1.000)", i.easeInOutSine = "cubic-bezier(0.445, 0.050, 0.550, 0.950)", i.easeInBack = "cubic-bezier(0.600, -0.280, 0.735, 0.045)", i.easeOutBack = "cubic-bezier(0.175,  0.885, 0.320, 1.275)", i.easeInOutBack = "cubic-bezier(0.680, -0.550, 0.265, 1.550)", i.linear = "cubic-bezier(0.0, 0.0, 1.0, 1.0)", i.ease = "cubic-bezier(0.25, 0.1, 0.25, 1.0)", i["ease-in"] = "cubic-bezier(0.42, 0.0, 1.0, 1.0)", i["ease-out"] = "cubic-bezier(0.0, 0.0, 0.58, 1.0)", i["ease-in-out"] = "cubic-bezier(0.42, 0.0, 0.58, 1.0)", t.exports = i
    }, {}],
    22: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = 1e-5,
            a = Math.abs,
            o = 5,
            l = function() {
                function e(t, r, n, s) {
                    i(this, e), this.cp = new Float32Array(6), this.cp[0] = 3 * t, this.cp[1] = 3 * (n - t) - this.cp[0], this.cp[2] = 1 - this.cp[0] - this.cp[1], this.cp[3] = 3 * r, this.cp[4] = 3 * (s - r) - this.cp[3], this.cp[5] = 1 - this.cp[3] - this.cp[4]
                }
                return n(e, [{
                    key: "sampleCurveX",
                    value: function(e) {
                        return ((this.cp[2] * e + this.cp[1]) * e + this.cp[0]) * e
                    }
                }, {
                    key: "sampleCurveY",
                    value: function(e) {
                        return ((this.cp[5] * e + this.cp[4]) * e + this.cp[3]) * e
                    }
                }, {
                    key: "sampleCurveDerivativeX",
                    value: function(e) {
                        return (3 * this.cp[2] * e + 2 * this.cp[1]) * e + this.cp[0]
                    }
                }, {
                    key: "solveCurveX",
                    value: function(e) {
                        var t, r, i, n, l, c;
                        for (i = e, c = 0; c < o; c++) {
                            if (n = this.sampleCurveX(i) - e, a(n) < s) return i;
                            if (l = this.sampleCurveDerivativeX(i), a(l) < s) break;
                            i -= n / l
                        }
                        if (t = 0, r = 1, i = e, i < t) return t;
                        if (i > r) return r;
                        for (; t < r;) {
                            if (n = this.sampleCurveX(i), a(n - e) < s) return i;
                            e > n ? t = i : r = i, i = .5 * (r - t) + t
                        }
                        return i
                    }
                }, {
                    key: "solve",
                    value: function(e) {
                        return this.sampleCurveY(this.solveCurveX(e))
                    }
                }]), e
            }(),
            c = /\d*\.?\d+/g;
        l.fromCSSString = function(e) {
            var t = e.match(c);
            if (4 !== t.length) throw "UnitBezier could not convert " + e + " to cubic-bezier";
            var r = t.map(Number),
                i = new l(r[0], r[1], r[2], r[3]);
            return i.solve.bind(i)
        }, t.exports = l
    }, {}],
    23: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            this.el = e, this._options = t || {}, this._wrapper = this.el.querySelector(this._options.itemsSelector), this._items = Array.prototype.slice.call(this.el.querySelectorAll(this._options.itemSelector)), this.lastCenteredItem = this._items[0], this._isRightToLeft = "rtl" === window.getComputedStyle(e).direction, this._inlineStart = this._isRightToLeft ? "right" : "left", this._inlineEnd = this._isRightToLeft ? "left" : "right", this._scrollType = this._scrollDirection(), this._usePaddles = void 0 === this._options.usePaddles || this._options.usePaddles, this.centerItem = this.centerItem.bind(this), this._init()
        }
        var n = e("@marcom/dom-metrics/getDimensions"),
            s = e("@marcom/dom-metrics/getPosition"),
            a = e("@marcom/clip"),
            o = e("@marcom/anim-system/Model/UnitBezier"),
            l = e("@marcom/anim-system/Model/BezierMap"),
            c = i.prototype;
        c._init = function() {
            this._usePaddles && this._setupPaddles()
        }, c.centerItem = function(e, t) {
            this.lastCenteredItem = e;
            var r = n(this.el).width,
                i = .5 * r,
                a = s(e).left,
                o = n(e).width,
                l = a + .5 * o,
                c = Math.round(l - i);
            return t ? void(this.el.scrollLeft = this._setNormalizedScroll(c)) : (this._destroyCurrentClip(), this._isRightToLeft && (c *= -1), void this._smoothScrollTo(c))
        }, c._getPaddles = function() {
            var e = this._isRightToLeft ? this._options.rightPaddleSelector : this._options.leftPaddleSelector,
                t = this._isRightToLeft ? this._options.leftPaddleSelector : this._options.rightPaddleSelector;
            return {
                start: this.el.querySelector(e),
                end: this.el.querySelector(t)
            }
        }, c._setupPaddles = function() {
            this.el.classList.add("with-paddles"), this._paddles = this._getPaddles(), this._children = this._wrapper.children, this._childCount = this._wrapper.children.length, this._onScrollClipComplete = this._onScrollClipComplete.bind(this), this._onPaddleStartClick = this._onPaddleStartClick.bind(this), this._paddles.start.addEventListener("click", this._onPaddleStartClick), this._onPaddleEndClick = this._onPaddleEndClick.bind(this), this._paddles.end.addEventListener("click", this._onPaddleEndClick), this._onScroll = this._onScroll.bind(this), this._wrapper.addEventListener("scroll", this._onScroll), this._updateElementMetrics = this._updateElementMetrics.bind(this), window.addEventListener("resize", this._updateElementMetrics), window.addEventListener("orientationchange", this._updateElementMetrics), this._updateElementMetrics()
        }, c._updateElementMetrics = function() {
            this._wrapperWidth = this._wrapper.offsetWidth, this._contentWidth = this._wrapper.scrollWidth, this._contentWidth <= this._wrapperWidth && (this._destroyCurrentClip(), 0 !== this._wrapper.scrollLeft && (this._wrapper.scrollLeft = 0)), this._scrollStart = this._wrapper.scrollLeft, this._usePaddles && (this._paddleWidth = this._paddles.start.offsetWidth, this._updatePaddleDisplay())
        }, c._onScroll = function() {
            this._lockPaddles || (this._scrollStart = this._wrapper.scrollLeft, this._updatePaddleDisplay())
        }, c._updatePaddleDisplay = function() {
            var e = this._getNormalizedScroll(this._scrollStart) + this._wrapperWidth,
                t = 1;
            this._paddles.start.disabled = this._getNormalizedScroll(this._scrollStart) <= t, this._paddles.end.disabled = e >= this._contentWidth - t
        }, c._onPaddleStartClick = function(e) {
            this._smoothScrollTo(this._getPaddleStartScrollDestination())
        }, c._getPaddleStartScrollDestination = function() {
            var e, t, r = this._getNormalizedScroll(this._scrollStart);
            for (t = this._childCount - 1; t > 0; t--)
                if (e = this._normalizePosition(s(this._children[t])), e[this._inlineStart] < r) return e[this._inlineEnd] - this._wrapperWidth;
            return 0
        }, c._onPaddleEndClick = function(e) {
            this._smoothScrollTo(this._getPaddleEndScrollDestination())
        }, c._getPaddleEndScrollDestination = function() {
            var e, t, r = this._getNormalizedScroll(this._scrollStart) + this._wrapperWidth;
            for (t = 0; t < this._childCount; t++)
                if (e = this._normalizePosition(s(this._children[t])), e[this._inlineEnd] > r) return e[this._inlineStart];
            return this._contentWidth
        }, c._getBoundedScrollX = function(e) {
            var t = this._contentWidth - this._wrapperWidth;
            return Math.max(Math.min(e, t), 0)
        }, c._smoothScrollTo = function(e) {
            var t = this;
            if (this._updateElementMetrics(), !this._lockPaddles && e !== this._scrollStart) {
                var r = this._wrapper.scrollLeft,
                    i = function(e, t, r) {
                        return e * (r - t) + t
                    },
                    n = {
                        ease: o.fromCSSString(l[this._options.scrollEasing]),
                        draw: function(n) {
                            t._wrapper.scrollLeft = i(n, r, t._setNormalizedScroll(e))
                        }
                    };
                this._usePaddles && (this._lockPaddles = !0), this._clip = new a(this._options.scrollDuration, n), this._clip.play().then(function() {
                    t._destroyCurrentClip(), t._clip = null, t._usePaddles && t._onScrollClipComplete()
                })
            }
        }, c._onScrollClipComplete = function() {
            this._updatePaddleDisplay(), this._lockPaddles = !1, this._onScroll()
        }, c._scrollDirection = function() {
            var e = "reverse",
                t = document.createElement("div");
            return t.style.cssText = "width:2px; height:1px; position:absolute; top:-1000px; overflow:scroll; font-size: 14px;", t.style.direction = "rtl", t.innerHTML = "test", document.body.appendChild(t), t.scrollLeft > 0 ? e = "default" : (t.scrollLeft = 1, 0 === t.scrollLeft && (e = "negative")), document.body.removeChild(t), e
        }, c._getNormalizedScroll = function(e) {
            if (!this._isRightToLeft) return e;
            var t = Math.abs(e);
            return "default" === this._scrollType && (t = this._contentWidth - this._wrapperWidth - t), t
        }, c._setNormalizedScroll = function(e) {
            var t = this._getBoundedScrollX(e);
            return this._isRightToLeft && "reverse" !== this._scrollType ? "negative" === this._scrollType ? -t : -(t - this._contentWidth + this._wrapperWidth) : t
        }, c._normalizePosition = function(e) {
            return this._isRightToLeft ? {
                top: e.top,
                right: this._wrapperWidth - e.right + this._paddleWidth,
                bottom: e.bottom,
                left: this._wrapperWidth - e.left + this._paddleWidth
            } : {
                top: e.top,
                right: e.right - this._paddleWidth,
                bottom: e.bottom,
                left: e.left - this._paddleWidth
            }
        }, c._destroyCurrentClip = function() {
            this._clip && this._clip._isPlaying && (this._clip.destroy(), this._lockPaddles = !1)
        }, c._destroyPaddles = function() {
            this._paddles.start.removeEventListener("click", this._onPaddleStartClick), this._paddles.end.removeEventListener("click", this._onPaddleEndClick), this._wrapper.removeEventListener("scroll", this._onScroll), this._paddles = null
        }, c.destroy = function() {
            this._items = null, this._destroyCurrentClip(), this._destroyPaddles(), window.removeEventListener("resize", this._updateElementMetrics), window.removeEventListener("orientationchange", this._updateElementMetrics)
        }, t.exports = i
    }, {
        "@marcom/anim-system/Model/BezierMap": 21,
        "@marcom/anim-system/Model/UnitBezier": 22,
        "@marcom/clip": 55,
        "@marcom/dom-metrics/getDimensions": 62,
        "@marcom/dom-metrics/getPosition": 63
    }],
    24: [function(e, t, r) {
        "use strict";
        var i = e("./ScrollContainer");
        t.exports = {
            ScrollContainer: i
        }
    }, {
        "./ScrollContainer": 23
    }],
    25: [function(e, t, r) {
        "use strict";
        t.exports = {
            SharedInstance: e("./ac-shared-instance/SharedInstance")
        }
    }, {
        "./ac-shared-instance/SharedInstance": 26
    }],
    26: [function(e, t, r) {
        "use strict";
        var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            },
            n = window,
            s = "AC",
            a = "SharedInstance",
            o = n[s],
            l = function() {
                var e = {};
                return {
                    get: function(t, r) {
                        var i = null;
                        return e[t] && e[t][r] && (i = e[t][r]), i
                    },
                    set: function(t, r, i) {
                        return e[t] || (e[t] = {}), "function" == typeof i ? e[t][r] = new i : e[t][r] = i, e[t][r]
                    },
                    share: function(e, t, r) {
                        var i = this.get(e, t);
                        return i || (i = this.set(e, t, r)), i
                    },
                    remove: function(t, r) {
                        var n = "undefined" == typeof r ? "undefined" : i(r);
                        if ("string" === n || "number" === n) {
                            if (!e[t] || !e[t][r]) return;
                            return void(e[t][r] = null)
                        }
                        e[t] && (e[t] = null)
                    }
                }
            }();
        o || (o = n[s] = {}), o[a] || (o[a] = l), t.exports = o[a]
    }, {}],
    27: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = function() {
                function e() {
                    var t = this,
                        r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    i(this, e), this.options = r, "loading" === document.readyState ? document.addEventListener("readystatechange", function(e) {
                        "interactive" === document.readyState && t._init()
                    }) : this._init()
                }
                return n(e, [{
                    key: "_init",
                    value: function() {
                        return this._images = Array.from(document.querySelectorAll("*[" + e.DATA_ATTRIBUTE + "]")), this.AnimSystem = this._findAnim(), null === this.AnimSystem ? null : void this._addKeyframesToImages()
                    }
                }, {
                    key: "_defineKeyframeOptions",
                    value: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                            r = t.getAttribute(e.DATA_DOWNLOAD_AREA_KEYFRAME) || "{}";
                        return Object.assign({}, {
                            start: "t - 200vh",
                            end: "b + 100vh",
                            event: "AnimLazyImage"
                        }, JSON.parse(r))
                    }
                }, {
                    key: "_addKeyframesToImages",
                    value: function() {
                        var e = this;
                        this._scrollGroup = this.AnimSystem.getGroupForTarget(document.body), this._images.forEach(function(t) {
                            var r = e._defineKeyframeOptions(t),
                                i = e._scrollGroup.addKeyframe(t, r);
                            i.controller.once("AnimLazyImage:enter", function() {
                                e._imageIsInLoadRange(t)
                            })
                        })
                    }
                }, {
                    key: "_cleanUpImageAttributes",
                    value: function(t) {
                        var r = !1;
                        try {
                            r = this._scrollGroup.getControllerForTarget(t).getNearestKeyframeForAttribute("AnimLazyImage").isCurrentlyInRange
                        } catch (i) {
                            r = !1
                        }
                        r || t.setAttribute(e.DATA_ATTRIBUTE, "")
                    }
                }, {
                    key: "_downloadingImageAttributes",
                    value: function(t) {
                        t.removeAttribute(e.DATA_ATTRIBUTE)
                    }
                }, {
                    key: "_imageIsInLoadRange",
                    value: function(e) {
                        this._downloadImage(e)
                    }
                }, {
                    key: "_downloadImage",
                    value: function(e) {
                        this._downloadingImageAttributes(e)
                    }
                }, {
                    key: "_findAnim",
                    value: function() {
                        var e = Array.from(document.querySelectorAll("[data-anim-group],[data-anim-scroll-group],[data-anim-time-group]"));
                        return e.map(function(e) {
                            return e._animInfo ? e._animInfo.group : null
                        }).filter(function(e) {
                            return null !== e
                        }), e[0] && e[0]._animInfo ? e[0]._animInfo.group.anim : (console.error("AnimLazyImage: AnimSystem not found, please initialize anim before instantiating"), null)
                    }
                }]), e
            }();
        s.DATA_DOWNLOAD_AREA_KEYFRAME = "data-download-area-keyframe", s.DATA_ATTRIBUTE = "data-anim-lazy-image", t.exports = s
    }, {}],
    28: [function(e, t, r) {
        "use strict";
        t.exports = {
            version: "3.0.10",
            major: "3.x",
            majorMinor: "3.0"
        }
    }, {}],
    29: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            l = e("./Model/AnimSystemModel"),
            c = e("./Keyframes/Keyframe"),
            u = e("./Keyframes/KeyframeCSSClass"),
            h = e("./Keyframes/KeyframeDiscreteEvent"),
            m = e("./ScrollGroup"),
            f = e("./TimeGroup"),
            p = e("./.release-info"),
            d = {
                update: e("@marcom/ac-raf-emitter/update"),
                cancelUpdate: e("@marcom/ac-raf-emitter/cancelUpdate"),
                external: e("@marcom/ac-raf-emitter/external"),
                draw: e("@marcom/ac-raf-emitter/draw")
            },
            v = null,
            _ = function(e) {
                function t() {
                    i(this, t);
                    var e = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    if (v) throw "You cannot create multiple AnimSystems. You probably want to create multiple groups instead. You can have unlimited groups on a page";
                    return v = e, e.groups = [], e.scrollSystems = [], e.timeSystems = [], e._forceUpdateRAFId = -1, e._initialized = !1, e.model = l, e.version = p.version, e.onScroll = e.onScroll.bind(e), e.onResizedDebounced = e.onResizedDebounced.bind(e), e.onResizeImmediate = e.onResizeImmediate.bind(e), e
                }
                return s(t, e), a(t, [{
                    key: "initialize",
                    value: function() {
                        this._initialized || (this._initialized = !0, this.timeSystems = [], this.scrollSystems = [], this.groups = [], this.setupEvents(), this.initializeResizeFilter(), this.initializeModel(), this.createDOMGroups(), this.createDOMKeyframes())
                    }
                }, {
                    key: "remove",
                    value: function() {
                        var e = this;
                        return Promise.all(this.groups.map(function(e) {
                            return e.remove()
                        })).then(function() {
                            e.groups = null, e.scrollSystems = null, e.timeSystems = null, window.clearTimeout(l.RESIZE_TIMEOUT), window.removeEventListener("scroll", e.onScroll), window.removeEventListener("resize", e.onResizeImmediate), e._events = {}, e._initialized = !1
                        })
                    }
                }, {
                    key: "destroy",
                    value: function() {
                        return this.remove()
                    }
                }, {
                    key: "createTimeGroup",
                    value: function(e) {
                        var t = new f(e, this);
                        return this.groups.push(t), this.timeSystems.push(t), this.trigger(l.EVENTS.ON_GROUP_CREATED, t), t
                    }
                }, {
                    key: "createScrollGroup",
                    value: function(e) {
                        if (!e) throw "AnimSystem scroll based groups must supply an HTMLElement";
                        var t = new m(e, this);
                        return this.groups.push(t), this.scrollSystems.push(t), this.trigger(l.EVENTS.ON_GROUP_CREATED, t), t
                    }
                }, {
                    key: "removeGroup",
                    value: function(e) {
                        var t = this;
                        return Promise.all(e.keyframeControllers.map(function(t) {
                            return e.removeKeyframeController(t)
                        })).then(function() {
                            var r = t.groups.indexOf(e);
                            r !== -1 && t.groups.splice(r, 1), r = t.scrollSystems.indexOf(e), r !== -1 && t.scrollSystems.splice(r, 1), r = t.timeSystems.indexOf(e), r !== -1 && t.timeSystems.splice(r, 1), e.destroy()
                        })
                    }
                }, {
                    key: "createDOMGroups",
                    value: function() {
                        var e = this;
                        document.body.setAttribute("data-anim-scroll-group", "body"), document.querySelectorAll("[data-anim-scroll-group]").forEach(function(t) {
                            return e.createScrollGroup(t)
                        }), document.querySelectorAll("[data-anim-time-group]").forEach(function(t) {
                            return e.createTimeGroup(t)
                        }), this.trigger(l.EVENTS.ON_DOM_GROUPS_CREATED, this.groups)
                    }
                }, {
                    key: "createDOMKeyframes",
                    value: function() {
                        var e = this,
                            t = [];
                        [c.DATA_ATTRIBUTE, u.DATA_ATTRIBUTE, h.DATA_ATTRIBUTE].forEach(function(e) {
                            for (var r = 0; r < 12; r++) t.push(e + (0 === r ? "" : "-" + (r - 1)))
                        });
                        for (var r = 0; r < t.length; r++)
                            for (var i = t[r], n = document.querySelectorAll("[" + i + "]"), s = 0; s < n.length; s++) {
                                var a = n[s],
                                    o = JSON.parse(a.getAttribute(i));
                                this.addKeyframe(a, o)
                            }
                        d.update(function() {
                            e.groups.forEach(function(e) {
                                return e.onKeyframesDirty({
                                    silent: !0
                                })
                            }), e.groups.forEach(function(e) {
                                return e.trigger(l.EVENTS.ON_DOM_KEYFRAMES_CREATED, e)
                            }), e.trigger(l.EVENTS.ON_DOM_KEYFRAMES_CREATED, e), e.groups.forEach(function(e) {
                                e.forceUpdate({
                                    waitForNextUpdate: !1,
                                    silent: !0
                                }), e.reconcile()
                            }), e.onScroll()
                        }, !0)
                    }
                }, {
                    key: "initializeResizeFilter",
                    value: function() {
                        if (!l.cssDimensionsTracker) {
                            var e = document.querySelector(".cssDimensionsTracker") || document.createElement("div");
                            e.setAttribute("cssDimensionsTracker", "true"), e.style.position = "fixed", e.style.top = "0", e.style.width = "100%", e.style.height = "100vh", e.style.pointerEvents = "none", e.style.visibility = "hidden", e.style.zIndex = "-1", document.documentElement.appendChild(e), l.cssDimensionsTracker = e
                        }
                    }
                }, {
                    key: "initializeModel",
                    value: function() {
                        l.pageMetrics.windowHeight = l.cssDimensionsTracker.clientHeight, l.pageMetrics.windowWidth = l.cssDimensionsTracker.clientWidth, l.pageMetrics.scrollY = window.scrollY || window.pageYOffset, l.pageMetrics.scrollX = window.scrollX || window.pageXOffset, l.pageMetrics.breakpoint = l.getBreakpoint();
                        var e = document.documentElement.getBoundingClientRect();
                        l.pageMetrics.documentOffsetX = e.left + l.pageMetrics.scrollX, l.pageMetrics.documentOffsetY = e.top + l.pageMetrics.scrollY
                    }
                }, {
                    key: "setupEvents",
                    value: function() {
                        window.removeEventListener("scroll", this.onScroll), window.addEventListener("scroll", this.onScroll), window.removeEventListener("resize", this.onResizeImmediate), window.addEventListener("resize", this.onResizeImmediate)
                    }
                }, {
                    key: "onScroll",
                    value: function() {
                        l.pageMetrics.scrollY = window.scrollY || window.pageYOffset, l.pageMetrics.scrollX = window.scrollX || window.pageXOffset;
                        for (var e = 0, t = this.scrollSystems.length; e < t; e++) this.scrollSystems[e]._onScroll();
                        this.trigger(l.PageEvents.ON_SCROLL, l.pageMetrics)
                    }
                }, {
                    key: "onResizeImmediate",
                    value: function() {
                        var e = l.cssDimensionsTracker.clientWidth,
                            t = l.cssDimensionsTracker.clientHeight;
                        if (e !== l.pageMetrics.windowWidth || t !== l.pageMetrics.windowHeight) {
                            l.pageMetrics.windowWidth = e, l.pageMetrics.windowHeight = t, l.pageMetrics.scrollY = window.scrollY || window.pageYOffset, l.pageMetrics.scrollX = window.scrollX || window.pageXOffset;
                            var r = document.documentElement.getBoundingClientRect();
                            l.pageMetrics.documentOffsetX = r.left + l.pageMetrics.scrollX, l.pageMetrics.documentOffsetY = r.top + l.pageMetrics.scrollY, window.clearTimeout(l.RESIZE_TIMEOUT), l.RESIZE_TIMEOUT = window.setTimeout(this.onResizedDebounced, 250), this.trigger(l.PageEvents.ON_RESIZE_IMMEDIATE, l.pageMetrics)
                        }
                    }
                }, {
                    key: "onResizedDebounced",
                    value: function() {
                        var e = this;
                        d.update(function() {
                            var t = l.pageMetrics.breakpoint,
                                r = l.getBreakpoint(),
                                i = r !== t;
                            if (i) {
                                l.pageMetrics.previousBreakpoint = t, l.pageMetrics.breakpoint = r;
                                for (var n = 0, s = e.groups.length; n < s; n++) e.groups[n]._onBreakpointChange();
                                e.trigger(l.PageEvents.ON_BREAKPOINT_CHANGE, l.pageMetrics)
                            }
                            for (var a = 0, o = e.groups.length; a < o; a++) e.groups[a].forceUpdate({
                                waitForNextUpdate: !1
                            });
                            e.trigger(l.PageEvents.ON_RESIZE_DEBOUNCED, l.pageMetrics)
                        }, !0)
                    }
                }, {
                    key: "forceUpdate",
                    value: function() {
                        var e = this,
                            t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            r = t.waitForNextUpdate,
                            i = void 0 === r || r,
                            n = t.silent,
                            s = void 0 !== n && n;
                        this._forceUpdateRAFId !== -1 && d.cancelUpdate(this._forceUpdateRAFId);
                        var a = function() {
                            for (var t = 0, r = e.groups.length; t < r; t++) {
                                var i = e.groups[t];
                                i.forceUpdate({
                                    waitForNextUpdate: !1,
                                    silent: s
                                })
                            }
                            return -1
                        };
                        this._forceUpdateRAFId = i ? d.update(a, !0) : a()
                    }
                }, {
                    key: "addKeyframe",
                    value: function(e, t) {
                        var r = this.getGroupForTarget(e);
                        return r = r || this.getGroupForTarget(document.body), r.addKeyframe(e, t)
                    }
                }, {
                    key: "getGroupForTarget",
                    value: function(e) {
                        if (e._animInfo && e._animInfo.group) return e._animInfo.group;
                        for (var t = e; t;) {
                            if (t._animInfo && t._animInfo.isGroup) return t._animInfo.group;
                            t = t.parentElement
                        }
                    }
                }, {
                    key: "getControllerForTarget",
                    value: function(e) {
                        return e._animInfo && e._animInfo.controller ? e._animInfo.controller : null
                    }
                }]), t
            }(o);
        t.exports = window.AC.SharedInstance.share("AnimSystem", p.major, _)
    }, {
        "./.release-info": 28,
        "./Keyframes/Keyframe": 30,
        "./Keyframes/KeyframeCSSClass": 31,
        "./Keyframes/KeyframeDiscreteEvent": 33,
        "./Model/AnimSystemModel": 34,
        "./ScrollGroup": 42,
        "./TimeGroup": 43,
        "@marcom/ac-event-emitter-micro": 4,
        "@marcom/ac-raf-emitter/cancelUpdate": 13,
        "@marcom/ac-raf-emitter/draw": 14,
        "@marcom/ac-raf-emitter/external": 15,
        "@marcom/ac-raf-emitter/update": 18
    }],
    30: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = e("../Model/AnimSystemModel"),
            a = e("@marcom/sm-math-utils"),
            o = e("../Model/EasingFunctions"),
            l = e("../Model/UnitBezier"),
            c = e("../utils/arrayToObject"),
            u = e("../utils/toValidAnchor"),
            h = function() {
                function e(t, r) {
                    i(this, e), this.controller = t, this.anchors = [], this.jsonProps = r, this.ease = t.group.defaultEase, this.easeFunctionString = s.KeyframeDefaults.easeFunctionString, this.easeFunction = o[this.easeFunctionString], this.start = 0, this.end = 0, this.localT = 0, this.curvedT = 0, this.id = 0, this.event = "", this.needsEventDispatch = !1, this.snapAtCreation = !1, this.isEnabled = !1, this.animValues = {}, this.breakpointMask = "SMLX", this.disabledWhen = [], this.keyframeType = s.KeyframeTypes.Interpolation, this.hold = !1
                }
                return n(e, [{
                    key: "destroy",
                    value: function() {
                        this.controller = null, this.disabledWhen = null, this.anchors = null, this.jsonProps = null, this.easeFunction = null, this.animValues = null
                    }
                }, {
                    key: "remove",
                    value: function() {
                        return this.controller.removeKeyframe(this)
                    }
                }, {
                    key: "parseOptions",
                    value: function(e) {
                        var t = this;
                        if (this.jsonProps = e, e.relativeTo && console.error("KeyframeError: relativeTo has been removed. Use 'anchors' property instead. Found 'relativeTo':\"" + e.relativeTo + '"'), "" !== e.anchors && e.anchors ? (this.anchors = [], e.anchors = Array.isArray(e.anchors) ? e.anchors : [e.anchors], e.anchors.forEach(function(r, i) {
                                var n = u(r, t.controller.group.element);
                                if (!n) {
                                    var s = "";
                                    return "string" == typeof r && (s = " Provided value was a string, so a failed attempt was made to find anchor with the provided querystring in group.element, or in the document."), void console.warn("Keyframe on", t.controller.element, " failed to find anchor at index " + i + " in array", e.anchors, ". Anchors must be JS Object references, Elements references, or valid query selector strings. " + s)
                                }
                                t.anchors.push(n), t.controller.group.metrics.add(n)
                            })) : (this.anchors = [], e.anchors = []), e.ease ? this.ease = parseFloat(e.ease) : e.ease = this.ease, e.hasOwnProperty("snapAtCreation") ? this.snapAtCreation = e.snapAtCreation : e.snapAtCreation = this.snapAtCreation, e.easeFunction ? this.easeFunction = e.easeFunction : e.easeFunction = this.easeFunctionString, e.breakpointMask ? this.breakpointMask = e.breakpointMask : e.breakpointMask = this.breakpointMask, e.disabledWhen ? this.disabledWhen = Array.isArray(e.disabledWhen) ? e.disabledWhen : [e.disabledWhen] : e.disabledWhen = this.disabledWhen, e.hasOwnProperty("hold") ? this.hold = e.hold : e.hold = this.hold, this.easeFunction = o[e.easeFunction], !o.hasOwnProperty(e.easeFunction)) {
                            var r = l.fromCSSString(e.easeFunction);
                            r ? this.easeFunction = r : console.error("Keyframe parseOptions cannot find EasingFunction named '" + e.easingFunction + "'")
                        }
                        for (var i in e)
                            if (s.KeyframeJSONReservedWords.indexOf(i) === -1) {
                                var n = e[i];
                                if (Array.isArray(n)) {
                                    if (this.animValues[i] = this.controller.group.expressionParser.parseArray(this, n), void 0 === this.controller.tweenProps[i] || !this.controller._ownerIsElement) {
                                        var a = 0;
                                        this.controller._ownerIsElement || (a = this.controller.element[i] || 0);
                                        var c = new s.TargetValue(a, s.KeyframeDefaults.epsilon, this.snapAtCreation);
                                        this.controller.tweenProps[i] = c
                                    }
                                    var h = this.controller.tweenProps[i];
                                    if (e.epsilon) h.epsilon = e.epsilon;
                                    else {
                                        var m = Math.abs(this.animValues[i][0] - this.animValues[i][1]),
                                            f = Math.min(.001 * m, h.epsilon, s.KeyframeDefaults.epsilon);
                                        h.epsilon = Math.max(f, 1e-4)
                                    }
                                }
                            }
                        this.keyframeType = this.hold ? s.KeyframeTypes.InterpolationForward : s.KeyframeTypes.Interpolation, e.event && (this.event = e.event)
                    }
                }, {
                    key: "overwriteProps",
                    value: function(e) {
                        this.animValues = {};
                        var t = Object.assign({}, this.jsonProps, e);
                        this.controller.updateKeyframe(this, t)
                    }
                }, {
                    key: "updateLocalProgress",
                    value: function(e) {
                        if (this.start === this.end || e < this.start || e > this.end) return this.localT = e < this.start ? 0 : e > this.end ? 1 : 0, void(this.curvedT = this.easeFunction(this.localT));
                        var t = (e - this.start) / (this.end - this.start),
                            r = this.hold ? this.localT : 0;
                        this.localT = a.clamp(t, r, 1), this.curvedT = this.easeFunction(this.localT)
                    }
                }, {
                    key: "reconcile",
                    value: function(e) {
                        var t = this.animValues[e],
                            r = this.controller.tweenProps[e];
                        r.initialValue = t[0], r.target = t[0] + this.curvedT * (t[1] - t[0]), r.current !== r.target && (r.current = r.target, this.needsEventDispatch || (this.needsEventDispatch = !0, this.controller.keyframesRequiringDispatch.push(this)))
                    }
                }, {
                    key: "reset",
                    value: function(e) {
                        this.localT = e || 0;
                        var t = this.ease;
                        this.ease = 1;
                        for (var r in this.animValues) this.reconcile(r);
                        this.ease = t
                    }
                }, {
                    key: "onDOMRead",
                    value: function(e) {
                        var t = this.animValues[e],
                            r = this.controller.tweenProps[e];
                        r.target = t[0] + this.curvedT * (t[1] - t[0]);
                        var i = r.current;
                        r.current += (r.target - r.current) * this.ease;
                        var n = r.current - r.target;
                        n < r.epsilon && n > -r.epsilon && (r.current = r.target, n = 0), "" === this.event || this.needsEventDispatch || (n > r.epsilon || n < -r.epsilon || 0 === n && i !== r.current) && (this.needsEventDispatch = !0, this.controller.keyframesRequiringDispatch.push(this))
                    }
                }, {
                    key: "isInRange",
                    value: function(e) {
                        return e >= this.start && e <= this.end
                    }
                }, {
                    key: "setEnabled",
                    value: function(e) {
                        e = e || c(Array.from(document.documentElement.classList));
                        var t = this.breakpointMask.indexOf(s.pageMetrics.breakpoint) !== -1,
                            r = !1;
                        return this.disabledWhen.length > 0 && (r = this.disabledWhen.some(function(t) {
                            return "undefined" != typeof e[t]
                        })), this.isEnabled = t && !r, this.isEnabled
                    }
                }, {
                    key: "evaluateConstraints",
                    value: function() {
                        this.start = this.controller.group.expressionParser.parseTimeValue(this, this.jsonProps.start), this.end = this.controller.group.expressionParser.parseTimeValue(this, this.jsonProps.end), this.evaluateInterpolationConstraints()
                    }
                }, {
                    key: "evaluateInterpolationConstraints",
                    value: function() {
                        for (var e in this.animValues) {
                            var t = this.jsonProps[e];
                            this.animValues[e] = this.controller.group.expressionParser.parseArray(this, t)
                        }
                    }
                }]), e
            }();
        h.DATA_ATTRIBUTE = "data-anim-tween", t.exports = h
    }, {
        "../Model/AnimSystemModel": 34,
        "../Model/EasingFunctions": 35,
        "../Model/UnitBezier": 39,
        "../utils/arrayToObject": 44,
        "../utils/toValidAnchor": 45,
        "@marcom/sm-math-utils": 68
    }],
    31: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            },
            o = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            l = e("./Keyframe"),
            c = e("../Model/AnimSystemModel.js"),
            u = function(e) {
                function t(e, r) {
                    i(this, t);
                    var s = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e, r));
                    return s.keyframeType = c.KeyframeTypes.CSSClass, s._triggerType = t.TRIGGER_TYPE_CSS_CLASS, s.cssClass = "", s.friendlyName = "", s.style = {
                        on: null,
                        off: null
                    }, s.toggle = !1, s.isApplied = !1, s
                }
                return s(t, e), o(t, [{
                    key: "parseOptions",
                    value: function(e) {
                        if (!this.controller._ownerIsElement) throw new TypeError("CSS Keyframes cannot be applied to JS Objects");
                        if (e.x = void 0, e.y = void 0, e.scale = void 0, e.scaleX = void 0, e.scaleY = void 0, e.rotation = void 0, e.opacity = void 0, e.hold = void 0, void 0 !== e.toggle && (this.toggle = e.toggle), void 0 !== e.cssClass) this._triggerType = t.TRIGGER_TYPE_CSS_CLASS, this.cssClass = e.cssClass, this.friendlyName = "." + this.cssClass, void 0 === this.controller.tweenProps.targetClasses && (this.controller.tweenProps.targetClasses = {
                            add: [],
                            remove: []
                        });
                        else {
                            if (void 0 === e.style || !this.isValidStyleProperty(e.style)) throw new TypeError("KeyframeCSSClass no 'cssClass` property found. If using `style` property its also missing or invalid");
                            if (this._triggerType = t.TRIGGER_TYPE_STYLE_PROPERTY, this.style = e.style, this.friendlyName = "style", this.toggle = void 0 !== this.style.off || this.toggle, this.toggle && void 0 === this.style.off) {
                                this.style.off = {};
                                for (var r in this.style.on) this.style.off[r] = ""
                            }
                            void 0 === this.controller.tweenProps.targetStyles && (this.controller.tweenProps.targetStyles = {})
                        }
                        if (void 0 === e.end && (e.end = e.start), e.toggle = this.toggle, this._triggerType === t.TRIGGER_TYPE_CSS_CLASS) this.isApplied = this.controller.element.classList.contains(this.cssClass);
                        else {
                            var i = getComputedStyle(this.controller.element);
                            this.isApplied = !0;
                            for (var n in this.style.on)
                                if (i[n] !== this.style.on[n]) {
                                    this.isApplied = !1;
                                    break
                                }
                        }
                        l.prototype.parseOptions.call(this, e), this.animValues[this.friendlyName] = [0, 0], void 0 === this.controller.tweenProps[this.friendlyName] && (this.controller.tweenProps[this.friendlyName] = new c.TargetValue(0, 1, (!1))), this.keyframeType = c.KeyframeTypes.CSSClass
                    }
                }, {
                    key: "updateLocalProgress",
                    value: function(e) {
                        this.isApplied && !this.toggle || (this.start !== this.end ? !this.isApplied && e >= this.start && e <= this.end ? this._apply() : this.isApplied && this.toggle && (e < this.start || e > this.end) && this._unapply() : !this.isApplied && e >= this.start ? this._apply() : this.isApplied && this.toggle && e < this.start && this._unapply())
                    }
                }, {
                    key: "_apply",
                    value: function() {
                        if (this._triggerType === t.TRIGGER_TYPE_CSS_CLASS) this.controller.tweenProps.targetClasses.add.push(this.cssClass), this.controller.needsClassUpdate = !0;
                        else {
                            for (var e in this.style.on) this.controller.tweenProps.targetStyles[e] = this.style.on[e];
                            this.controller.needsStyleUpdate = !0
                        }
                        this.isApplied = !0
                    }
                }, {
                    key: "_unapply",
                    value: function() {
                        if (this._triggerType === t.TRIGGER_TYPE_CSS_CLASS) this.controller.tweenProps.targetClasses.remove.push(this.cssClass), this.controller.needsClassUpdate = !0;
                        else {
                            for (var e in this.style.off) this.controller.tweenProps.targetStyles[e] = this.style.off[e];
                            this.controller.needsStyleUpdate = !0
                        }
                        this.isApplied = !1
                    }
                }, {
                    key: "isValidStyleProperty",
                    value: function(e) {
                        if (!e.hasOwnProperty("on")) return !1;
                        if ("object" !== a(e.on)) throw new TypeError("KeyframeCSSClass `style` property should be in the form of: {on:{visibility:hidden, otherProperty: value}}");
                        if (this.toggle && e.hasOwnProperty("off") && "object" !== a(e.off)) throw new TypeError("KeyframeCSSClass `style` property should be in the form of: {on:{visibility:hidden, otherProperty: value}}");
                        return !0
                    }
                }, {
                    key: "reconcile",
                    value: function(e, t) {}
                }, {
                    key: "onDOMRead",
                    value: function(e, t) {}
                }, {
                    key: "evaluateInterpolationConstraints",
                    value: function() {}
                }]), t
            }(l);
        u.TRIGGER_TYPE_CSS_CLASS = 0, u.TRIGGER_TYPE_STYLE_PROPERTY = 1, u.DATA_ATTRIBUTE = "data-anim-classname", t.exports = u
    }, {
        "../Model/AnimSystemModel.js": 34,
        "./Keyframe": 30
    }],
    32: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = function b(e, t, r) {
                null === e && (e = Function.prototype);
                var i = Object.getOwnPropertyDescriptor(e, t);
                if (void 0 === i) {
                    var n = Object.getPrototypeOf(e);
                    return null === n ? void 0 : b(n, t, r)
                }
                if ("value" in i) return i.value;
                var s = i.get;
                if (void 0 !== s) return s.call(r)
            },
            l = e("../Model/AnimSystemModel"),
            c = (e("./Keyframe"), e("./KeyframeCSSClass")),
            u = e("../Model/InferKeyframeFromProps"),
            h = e("../utils/arrayToObject"),
            m = e("../Model/UUID"),
            f = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            p = e("@marcom/decompose-css-transform"),
            d = {
                update: e("@marcom/ac-raf-emitter/update"),
                external: e("@marcom/ac-raf-emitter/external"),
                draw: e("@marcom/ac-raf-emitter/draw")
            },
            v = Math.PI / 180,
            _ = {
                create: e("gl-mat4/create"),
                rotateX: e("gl-mat4/rotateX"),
                rotateY: e("gl-mat4/rotateY"),
                rotateZ: e("gl-mat4/rotateZ"),
                scale: e("gl-mat4/scale")
            },
            y = function(e) {
                function t(e, r) {
                    i(this, t);
                    var s = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return s._events.draw = [], s.uuid = m(), s.group = e, s.element = r, s._ownerIsElement = s.element instanceof Element, s._ownerIsElement ? s.friendlyName = s.element.tagName + "." + Array.from(s.element.classList).join(".") : s.friendlyName = s.element.friendlyName || s.uuid, s.element._animInfo = s.element._animInfo || new l.AnimInfo(e, s), s.element._animInfo.controller = s, s.element._animInfo.group = s.group, s.element._animInfo.controllers.push(s), s.tweenProps = s.element._animInfo.tweenProps, s.eventObject = new l.EventObject(s), s.needsStyleUpdate = !1, s.needsClassUpdate = !1, s.elementMetrics = s.group.metrics.add(s.element), s.attributes = [], s.keyframes = {}, s._allKeyframes = [], s._activeKeyframes = [], s.keyframesRequiringDispatch = [], s.updateCachedValuesFromElement(), s.boundsMin = 0, s.boundsMax = 0, s.mat2d = new Float32Array(6), s.mat4 = _.create(), s.needsWrite = !0, s.onDOMWriteImp = s._ownerIsElement ? s.onDOMWriteForElement : s.onDOMWriteForObject, s
                }
                return s(t, e), a(t, [{
                    key: "destroy",
                    value: function() {
                        if (this.element._animInfo) {
                            this.element._animInfo.controller === this && (this.element._animInfo.controller = null);
                            var e = this.element._animInfo.controllers.indexOf(this);
                            e !== -1 && this.element._animInfo.controllers.splice(e, 1), 0 === this.element._animInfo.controllers.length ? this.element._animInfo = null : (this.element._animInfo.controller = this.element._animInfo.controllers[this.element._animInfo.controllers.length - 1], this.element._animInfo.group = this.element._animInfo.controller.group)
                        }
                        this.eventObject.controller = null, this.eventObject.element = null, this.eventObject.keyframe = null, this.eventObject.tweenProps = null, this.eventObject = null, this.elementMetrics = null, this.group = null, this.keyframesRequiringDispatch = null;
                        for (var r = 0; r < this._allKeyframes.length; r++) this._allKeyframes[r].destroy();
                        this._allKeyframes = null, this._activeKeyframes = null, this.attributes = null, this.keyframes = null, this.element = null, this.tweenProps = null, o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                    }
                }, {
                    key: "remove",
                    value: function() {
                        return this.group.removeKeyframeController(this)
                    }
                }, {
                    key: "updateCachedValuesFromElement",
                    value: function() {
                        var e = this;
                        if (this._ownerIsElement) {
                            var t = getComputedStyle(this.element),
                                r = p(this.element, !0),
                                i = l.KeyframeDefaults.epsilon,
                                n = !1;
                            ["x", "y", "z"].forEach(function(t, s) {
                                e.tweenProps[t] = new l.TargetValue(r.translation[s], i, n)
                            }), this.tweenProps.rotation = new l.TargetValue(r.eulerRotation[2], i, n), ["rotationX", "rotationY", "rotationZ"].forEach(function(t, s) {
                                e.tweenProps[t] = new l.TargetValue(r.eulerRotation[s], i, n)
                            }), this.tweenProps.scaleZ = new l.TargetValue(r.scale[0], i, n), ["scaleX", "scaleY", "scale"].forEach(function(t, s) {
                                e.tweenProps[t] = new l.TargetValue(r.scale[s], i, n)
                            }), this.tweenProps.opacity = new l.TargetValue(parseFloat(t.opacity), i, n)
                        }
                    }
                }, {
                    key: "addKeyframe",
                    value: function(e) {
                        var t = u(e);
                        if (!t) throw new Error("AnimSystem Cannot create keyframe for from options `" + e + "`");
                        var r = new t(this, e);
                        return r.parseOptions(e), r.id = this._allKeyframes.length, this._allKeyframes.push(r), r
                    }
                }, {
                    key: "needsUpdate",
                    value: function() {
                        for (var e = 0, t = this.attributes.length; e < t; e++) {
                            var r = this.attributes[e],
                                i = this.tweenProps[r],
                                n = Math.abs(i.current - i.target);
                            if (n > i.epsilon) return !0
                        }
                        return !1
                    }
                }, {
                    key: "updateLocalProgress",
                    value: function(e) {
                        for (var t = 0, r = this.attributes.length; t < r; t++) {
                            var i = this.attributes[t],
                                n = this.keyframes[this.attributes[t]];
                            if (1 !== n.length) {
                                var s = this.getNearestKeyframeForAttribute(i, e);
                                s && s.updateLocalProgress(e)
                            } else n[0].updateLocalProgress(e)
                        }
                    }
                }, {
                    key: "reconcile",
                    value: function() {
                        for (var e = 0, t = this.attributes.length; e < t; e++) {
                            var r = this.attributes[e],
                                i = this.getNearestKeyframeForAttribute(r, this.group.position.local);
                            i.updateLocalProgress(this.group.position.local), i.snapAtCreation && i.reconcile(r)
                        }
                    }
                }, {
                    key: "determineActiveKeyframes",
                    value: function(e) {
                        var t = this;
                        e = e || h(Array.from(document.documentElement.classList));
                        var r = this._activeKeyframes,
                            i = this.attributes;
                        this._activeKeyframes = [], this.attributes = [], this.keyframes = {};
                        for (var n = 0; n < this._allKeyframes.length; n++) {
                            var s = this._allKeyframes[n];
                            if (s.setEnabled(e)) {
                                this._activeKeyframes.push(s);
                                for (var a in s.animValues) this.keyframes[a] = this.keyframes[a] || [], this.keyframes[a].push(s), this.attributes.indexOf(a) === -1 && (this.attributes.push(a), this.tweenProps[a].isActive = !0)
                            }
                        }
                        var o = r.filter(function(e) {
                            return t._activeKeyframes.indexOf(e) === -1
                        });
                        if (0 !== o.length) {
                            var l = i.filter(function(e) {
                                return t.attributes.indexOf(e) === -1
                            });
                            if (0 !== l.length)
                                if (this.needsWrite = !0, this._ownerIsElement) d.external(function() {
                                    var e = ["x", "y", "z", "scale", "scaleX", "scaleY", "rotation", "rotationX", "rotationY", "rotationZ"],
                                        r = l.filter(function(t) {
                                            return e.indexOf(t) !== -1
                                        });
                                    r.length > 0 && t.element.style.removeProperty("transform");
                                    for (var i = 0, n = l.length; i < n; ++i) {
                                        var s = l[i],
                                            a = t.tweenProps[s];
                                        a.current = a.target, a.isActive = !1, "opacity" === s && t.element.style.removeProperty("opacity")
                                    }
                                    for (var u = 0, h = o.length; u < h; ++u) {
                                        var m = o[u];
                                        m instanceof c && m._unapply()
                                    }
                                }, !0);
                                else
                                    for (var u = 0, m = l.length; u < m; ++u) {
                                        var f = this.tweenProps[l[u]];
                                        f.current = f.target, f.isActive = !1
                                    }
                        }
                    }
                }, {
                    key: "onDOMRead",
                    value: function(e) {
                        for (var t = 0, r = this.attributes.length; t < r; t++) {
                            var i = this.attributes[t];
                            this.tweenProps[i].previousValue = this.tweenProps[i].current;
                            var n = this.getNearestKeyframeForAttribute(i, e.local);
                            n && n.onDOMRead(i), this.tweenProps[i].previousValue !== this.tweenProps[i].current && (this.needsWrite = !0)
                        }
                    }
                }, {
                    key: "onDOMWrite",
                    value: function() {
                        (this.needsWrite || this.needsClassUpdate || this.needsStyleUpdate) && (this.needsWrite = !1, this.onDOMWriteImp(), this.handleEventDispatch())
                    }
                }, {
                    key: "onDOMWriteForObject",
                    value: function() {
                        for (var e = 0, t = this.attributes.length; e < t; e++) {
                            var r = this.attributes[e];
                            this.element[r] = this.tweenProps[r].current
                        }
                    }
                }, {
                    key: "onDOMWriteForElement",
                    value: function() {
                        var e = this.tweenProps;
                        if (e.z.isActive || e.rotationX.isActive || e.rotationY.isActive) {
                            var t = this.mat4;
                            if (t[0] = 1, t[1] = 0, t[2] = 0, t[3] = 0, t[4] = 0, t[5] = 1, t[6] = 0, t[7] = 0, t[8] = 0, t[9] = 0, t[10] = 1, t[11] = 0, t[12] = 0, t[13] = 0, t[14] = 0, t[15] = 1, e.x.isActive || e.y.isActive || e.z.isActive) {
                                var r = e.x.current,
                                    i = e.y.current,
                                    n = e.z.current;
                                t[12] = t[0] * r + t[4] * i + t[8] * n + t[12], t[13] = t[1] * r + t[5] * i + t[9] * n + t[13], t[14] = t[2] * r + t[6] * i + t[10] * n + t[14],
                                    t[15] = t[3] * r + t[7] * i + t[11] * n + t[15]
                            }
                            if (e.rotation.isActive || e.rotationZ.isActive) {
                                var s = (e.rotation.current || e.rotationZ.current) * v;
                                _.rotateZ(t, t, s)
                            }
                            if (e.rotationX.isActive) {
                                var a = e.rotationX.current * v;
                                _.rotateX(t, t, a)
                            }
                            if (e.rotationY.isActive) {
                                var o = e.rotationY.current * v;
                                _.rotateY(t, t, o)
                            }(e.scale.isActive || e.scaleX.isActive || e.scaleY.isActive) && _.scale(t, t, [e.scale.current, e.scale.current, 1]), this.element.style.transform = "matrix3d(" + t[0] + "," + t[1] + "," + t[2] + "," + t[3] + "," + t[4] + "," + t[5] + "," + t[6] + "," + t[7] + "," + t[8] + "," + t[9] + "," + t[10] + "," + t[11] + "," + t[12] + "," + t[13] + "," + t[14] + "," + t[15] + ")"
                        } else if (e.x.isActive || e.y.isActive || e.rotation.isActive || e.rotationZ.isActive || e.scale.isActive || e.scaleX.isActive || e.scaleY.isActive) {
                            var l = this.mat2d;
                            if (l[0] = 1, l[1] = 0, l[2] = 0, l[3] = 1, l[4] = 0, l[5] = 0, e.x.isActive || e.y.isActive) {
                                var c = e.x.current,
                                    u = e.y.current,
                                    h = l[0],
                                    m = l[1],
                                    f = l[2],
                                    p = l[3],
                                    d = l[4],
                                    y = l[5];
                                l[0] = h, l[1] = m, l[2] = f, l[3] = p, l[4] = h * c + f * u + d, l[5] = m * c + p * u + y
                            }
                            if (e.rotation.isActive || e.rotationZ.isActive) {
                                var b = (e.rotation.current || e.rotationZ.current) * v,
                                    g = l[0],
                                    E = l[1],
                                    w = l[2],
                                    A = l[3],
                                    S = l[4],
                                    O = l[5],
                                    k = Math.sin(b),
                                    x = Math.cos(b);
                                l[0] = g * x + w * k, l[1] = E * x + A * k, l[2] = g * -k + w * x, l[3] = E * -k + A * x, l[4] = S, l[5] = O
                            }
                            e.scale.isActive ? (l[0] = l[0] * e.scale.current, l[1] = l[1] * e.scale.current, l[2] = l[2] * e.scale.current, l[3] = l[3] * e.scale.current, l[4] = l[4], l[5] = l[5]) : (e.scaleX.isActive || e.scaleY.isActive) && (l[0] = l[0] * e.scaleX.current, l[1] = l[1] * e.scaleX.current, l[2] = l[2] * e.scaleY.current, l[3] = l[3] * e.scaleY.current, l[4] = l[4], l[5] = l[5]), this.element.style.transform = "matrix(" + l[0] + ", " + l[1] + ", " + l[2] + ", " + l[3] + ", " + l[4] + ", " + l[5] + ")"
                        }
                        if (e.opacity.isActive && (this.element.style.opacity = e.opacity.current), this.needsStyleUpdate) {
                            for (var P in this.tweenProps.targetStyles) null !== this.tweenProps.targetStyles[P] && (this.element.style[P] = this.tweenProps.targetStyles[P]), this.tweenProps.targetStyles[P] = null;
                            this.needsStyleUpdate = !1
                        }
                        this.needsClassUpdate && (this.tweenProps.targetClasses.add.length > 0 && this.element.classList.add.apply(this.element.classList, this.tweenProps.targetClasses.add), this.tweenProps.targetClasses.remove.length > 0 && this.element.classList.remove.apply(this.element.classList, this.tweenProps.targetClasses.remove), this.tweenProps.targetClasses.add.length = 0, this.tweenProps.targetClasses.remove.length = 0, this.needsClassUpdate = !1)
                    }
                }, {
                    key: "handleEventDispatch",
                    value: function() {
                        if (0 !== this.keyframesRequiringDispatch.length) {
                            for (var e = 0, t = this.keyframesRequiringDispatch.length; e < t; e++) {
                                var r = this.keyframesRequiringDispatch[e];
                                r.needsEventDispatch = !1, this.eventObject.keyframe = r, this.eventObject.pageMetrics = l.pageMetrics, this.eventObject.event = r.event, this.trigger(r.event, this.eventObject)
                            }
                            this.keyframesRequiringDispatch.length = 0
                        }
                        if (0 !== this._events.draw.length) {
                            this.eventObject.keyframe = null, this.eventObject.event = "draw";
                            for (var i = this._events.draw.length - 1; i >= 0; i--) this._events.draw[i](this.eventObject)
                        }
                    }
                }, {
                    key: "updateAnimationConstraints",
                    value: function() {
                        for (var e = this, t = 0, r = this._activeKeyframes.length; t < r; t++) this._activeKeyframes[t].evaluateConstraints();
                        this.attributes.forEach(function(t) {
                            1 !== e.keyframes[t].length && e.keyframes[t].sort(l.KeyframeComparison)
                        }), this.updateDeferredPropertyValues()
                    }
                }, {
                    key: "refreshMetrics",
                    value: function() {
                        var e = new Set([this.element]);
                        this._allKeyframes.forEach(function(t) {
                            return t.anchors.forEach(function(t) {
                                return e.add(t)
                            })
                        }), this.group.metrics.refreshCollection(e), this.group.keyframesDirty = !0
                    }
                }, {
                    key: "updateDeferredPropertyValues",
                    value: function() {
                        for (var e = 0, t = this.attributes.length; e < t; e++) {
                            var r = this.attributes[e],
                                i = this.keyframes[r],
                                n = i[0];
                            if (!(n.keyframeType > l.KeyframeTypes.InterpolationForward))
                                for (var s = 0, a = i.length; s < a; s++) {
                                    var o = i[s];
                                    if (null === o.jsonProps[r][0]) {
                                        if (0 === s) {
                                            o.animValues[r][0] = this.tweenProps[r].initialValue;
                                            continue
                                        }
                                        o.animValues[r][0] = i[s - 1].animValues[r][1]
                                    }
                                    if (null === o.jsonProps[r][1]) {
                                        if (s === a - 1) throw new RangeError("AnimSystem - last keyframe cannot defer it's end value! " + r + ":[" + o.jsonProps[r][0] + ",null]");
                                        o.animValues[r][1] = i[s + 1].animValues[r][0]
                                    }
                                }
                        }
                    }
                }, {
                    key: "getBounds",
                    value: function(e) {
                        this.boundsMin = Number.MAX_VALUE, this.boundsMax = -Number.MAX_VALUE;
                        for (var t = 0, r = this.attributes.length; t < r; t++)
                            for (var i = this.keyframes[this.attributes[t]], n = 0; n < i.length; n++) {
                                var s = i[n];
                                this.boundsMin = Math.min(s.start, this.boundsMin), this.boundsMax = Math.max(s.end, this.boundsMax), e.min = Math.min(s.start, e.min), e.max = Math.max(s.end, e.max)
                            }
                    }
                }, {
                    key: "getNearestKeyframeForAttribute",
                    value: function(e, t) {
                        t = void 0 !== t ? t : this.group.position.local;
                        var r = null,
                            i = Number.POSITIVE_INFINITY,
                            n = this.keyframes[e];
                        if (void 0 === n) return null;
                        var s = n.length;
                        if (0 === s) return null;
                        if (1 === s) return n[0];
                        for (var a = 0; a < s; a++) {
                            var o = n[a];
                            if (o.isInRange(t)) {
                                r = o;
                                break
                            }
                            var l = Math.min(Math.abs(t - o.start), Math.abs(t - o.end));
                            l < i && (i = l, r = o)
                        }
                        return r
                    }
                }, {
                    key: "getAllKeyframesForAttribute",
                    value: function(e) {
                        return this.keyframes[e]
                    }
                }, {
                    key: "updateKeyframe",
                    value: function(e, t) {
                        var r = this;
                        e.parseOptions(t), e.evaluateConstraints(), this.group.keyframesDirty = !0, d.update(function() {
                            r.trigger(l.EVENTS.ON_KEYFRAME_UPDATED, e), r.group.trigger(l.EVENTS.ON_KEYFRAME_UPDATED, e)
                        }, !0)
                    }
                }, {
                    key: "removeKeyframe",
                    value: function(e) {
                        var t = this,
                            r = this._allKeyframes.indexOf(e);
                        return r === -1 ? Promise.resolve(null) : (this._allKeyframes.splice(r, 1), this.group.keyframesDirty = !0, new Promise(function(r) {
                            t.group.rafEmitter.executor.eventEmitter.once("before:draw", function() {
                                r(e), e.destroy()
                            })
                        }))
                    }
                }, {
                    key: "updateAnimation",
                    value: function(e, t) {
                        return this.group.gui && console.warn("KeyframeController.updateAnimation(keyframe,props) has been deprecated. Please use updateKeyframe(keyframe,props)"), this.updateKeyframe(e, t)
                    }
                }]), t
            }(f);
        t.exports = y
    }, {
        "../Model/AnimSystemModel": 34,
        "../Model/InferKeyframeFromProps": 37,
        "../Model/UUID": 38,
        "../utils/arrayToObject": 44,
        "./Keyframe": 30,
        "./KeyframeCSSClass": 31,
        "@marcom/ac-event-emitter-micro": 4,
        "@marcom/ac-raf-emitter/draw": 14,
        "@marcom/ac-raf-emitter/external": 15,
        "@marcom/ac-raf-emitter/update": 18,
        "@marcom/decompose-css-transform": 60,
        "gl-mat4/create": 70,
        "gl-mat4/rotateX": 72,
        "gl-mat4/rotateY": 73,
        "gl-mat4/rotateZ": 74,
        "gl-mat4/scale": 75
    }],
    33: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = function h(e, t, r) {
                null === e && (e = Function.prototype);
                var i = Object.getOwnPropertyDescriptor(e, t);
                if (void 0 === i) {
                    var n = Object.getPrototypeOf(e);
                    return null === n ? void 0 : h(n, t, r)
                }
                if ("value" in i) return i.value;
                var s = i.get;
                if (void 0 !== s) return s.call(r)
            },
            l = e("./Keyframe"),
            c = e("../Model/AnimSystemModel.js"),
            u = function(e) {
                function t(e, r) {
                    i(this, t);
                    var s = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e, r));
                    return s.keyframeType = c.KeyframeTypes.Event, s.isApplied = !1, s.hasDuration = !1, s.isCurrentlyInRange = !1, s
                }
                return s(t, e), a(t, [{
                    key: "parseOptions",
                    value: function(e) {
                        e.x = void 0, e.y = void 0, e.scale = void 0, e.scaleX = void 0, e.scaleY = void 0, e.rotation = void 0, e.style = void 0, e.cssClass = void 0, e.rotation = void 0, e.opacity = void 0, e.hold = void 0, void 0 === e.end && (e.end = e.start), this.event = e.event, this.animValues[this.event] = [0, 0], "undefined" == typeof this.controller.tweenProps[this.event] && (this.controller.tweenProps[this.event] = new c.TargetValue(0, 1, (!1))), o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "parseOptions", this).call(this, e), this.keyframeType = c.KeyframeTypes.Event
                    }
                }, {
                    key: "updateLocalProgress",
                    value: function(e) {
                        if (this.hasDuration) {
                            var t = this.isCurrentlyInRange,
                                r = e >= this.start && e <= this.end;
                            if (t === r) return;
                            return this.isCurrentlyInRange = r, void(r && !t ? this._trigger(this.event + ":enter") : t && !r && this._trigger(this.event + ":exit"))
                        }!this.isApplied && e >= this.start ? (this.isApplied = !0, this._trigger(this.event)) : this.isApplied && e < this.start && (this.isApplied = !1, this._trigger(this.event + ":reverse"))
                    }
                }, {
                    key: "_trigger",
                    value: function(e) {
                        this.controller.eventObject.event = e, this.controller.eventObject.keyframe = this, this.controller.trigger(e, this.controller.eventObject)
                    }
                }, {
                    key: "evaluateConstraints",
                    value: function() {
                        o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "evaluateConstraints", this).call(this), this.hasDuration = this.start !== this.end
                    }
                }, {
                    key: "reset",
                    value: function(e) {
                        this.isApplied = !1, this.isCurrentlyInRange = !1, o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "reset", this).call(this, e)
                    }
                }, {
                    key: "onDOMRead",
                    value: function(e, t) {}
                }, {
                    key: "reconcile",
                    value: function(e, t) {}
                }, {
                    key: "evaluateInterpolationConstraints",
                    value: function() {}
                }]), t
            }(l);
        u.DATA_ATTRIBUTE = "data-anim-event", t.exports = u
    }, {
        "../Model/AnimSystemModel.js": 34,
        "./Keyframe": 30
    }],
    34: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = {
            GUI_INSTANCE: null,
            ANIM_INSTANCE: null,
            VIEWPORT_EMITTER_ELEMENT: void 0,
            LOCAL_STORAGE_KEYS: {
                GuiPosition: "anim-ui.position",
                GroupCollapsedStates: "anim-ui.group-collapsed-states",
                scrollY: "anim-ui.scrollY-position",
                path: "anim-ui.path"
            },
            RESIZE_TIMEOUT: -1,
            BREAKPOINTS: [{
                name: "S",
                mediaQuery: "only screen and (max-width: 735px)"
            }, {
                name: "M",
                mediaQuery: "only screen and (max-width: 1068px)"
            }, {
                name: "L",
                mediaQuery: "only screen and (min-width: 1442px)"
            }, {
                name: "L",
                mediaQuery: "only screen and (min-width: 1069px)"
            }],
            getBreakpoint: function() {
                for (var e = 0; e < n.BREAKPOINTS.length; e++) {
                    var t = n.BREAKPOINTS[e],
                        r = window.matchMedia(t.mediaQuery);
                    if (r.matches) return t.name
                }
            },
            KeyframeDefaults: {
                ease: 1,
                epsilon: .05,
                easeFunctionString: "linear",
                easeFunction: "linear",
                hold: !1,
                snapAtCreation: !1,
                toggle: !1,
                breakpointMask: "SMLX",
                event: "",
                disabledWhen: [],
                cssClass: ""
            },
            KeyframeTypes: {
                Interpolation: 0,
                InterpolationForward: 1,
                CSSClass: 2,
                Event: 3
            },
            EVENTS: {
                ON_DOM_KEYFRAMES_CREATED: "ON_DOM_KEYFRAMES_CREATED",
                ON_DOM_GROUPS_CREATED: "ON_DOM_GROUPS_CREATED",
                ON_GROUP_CREATED: "ON_GROUP_CREATED",
                ON_KEYFRAME_UPDATED: "ON_KEYFRAME_UPDATED",
                ON_TIMELINE_START: "ON_TIMELINE_START",
                ON_TIMELINE_UPDATE: "ON_TIMELINE_UPDATE",
                ON_TIMELINE_COMPLETE: "ON_TIMELINE_COMPLETE"
            },
            PageEvents: {
                ON_SCROLL: "ON_SCROLL",
                ON_RESIZE_IMMEDIATE: "ON_RESIZE_IMMEDIATE",
                ON_RESIZE_DEBOUNCED: "ON_RESIZE_DEBOUNCED",
                ON_BREAKPOINT_CHANGE: "ON_BREAKPOINT_CHANGE"
            },
            KeyframeJSONReservedWords: ["event", "cssClass", "style", "anchors", "start", "end", "epsilon", "easeFunction", "ease", "breakpointMask", "disabledWhen"],
            TweenProps: function s() {
                i(this, s)
            },
            TargetValue: function a(e, t, r) {
                i(this, a), this.epsilon = parseFloat(t), this.snapAtCreation = r, this.initialValue = e, this.target = e, this.current = e, this.previousValue = e, this.isActive = !1
            },
            AnimInfo: function(e, t) {
                var r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                this.isGroup = r, this.group = e, this.controller = t, this.controllers = [], this.tweenProps = new n.TweenProps
            },
            Progress: function() {
                this.local = 0, this.localUnclamped = 0, this.lastPosition = 0
            },
            ViewableRange: function(e, t) {
                this.a = e.top - t, this.a < 0 && (this.a = e.top), this.b = e.top, this.d = e.bottom, this.c = Math.max(this.d - t, this.b)
            },
            pageMetrics: new function() {
                this.scrollX = 0, this.scrollY = 0, this.windowWidth = 0, this.windowHeight = 0, this.documentOffsetX = 0, this.documentOffsetY = 0, this.previousBreakpoint = "", this.breakpoint = ""
            },
            EventObject: function(e) {
                this.controller = e, this.element = this.controller.element, this.keyframe = null, this.event = "", this.tweenProps = this.controller.tweenProps
            },
            KeyframeComparison: function(e, t) {
                return e.start < t.start ? -1 : e.start > t.start ? 1 : 0
            }
        };
        t.exports = n
    }, {}],
    35: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function s() {
            i(this, s), this.linear = function(e) {
                return e
            }, this.easeInQuad = function(e) {
                return e * e
            }, this.easeOutQuad = function(e) {
                return e * (2 - e)
            }, this.easeInOutQuad = function(e) {
                return e < .5 ? 2 * e * e : -1 + (4 - 2 * e) * e
            }, this.easeInSin = function(e) {
                return 1 + Math.sin(Math.PI / 2 * e - Math.PI / 2)
            }, this.easeOutSin = function(e) {
                return Math.sin(Math.PI / 2 * e)
            }, this.easeInOutSin = function(e) {
                return (1 + Math.sin(Math.PI * e - Math.PI / 2)) / 2
            }, this.easeInElastic = function(e) {
                return 0 === e ? e : (.04 - .04 / e) * Math.sin(25 * e) + 1
            }, this.easeOutElastic = function(e) {
                return .04 * e / --e * Math.sin(25 * e)
            }, this.easeInOutElastic = function(e) {
                return (e -= .5) < 0 ? (.02 + .01 / e) * Math.sin(50 * e) : (.02 - .01 / e) * Math.sin(50 * e) + 1
            }, this.easeOutBack = function(e) {
                return e -= 1, e * e * (2.70158 * e + 1.70158) + 1
            }, this.easeInCubic = function(e) {
                return e * e * e
            }, this.easeOutCubic = function(e) {
                return --e * e * e + 1
            }, this.easeInOutCubic = function(e) {
                return e < .5 ? 4 * e * e * e : (e - 1) * (2 * e - 2) * (2 * e - 2) + 1
            }, this.easeInQuart = function(e) {
                return e * e * e * e
            }, this.easeOutQuart = function(e) {
                return 1 - --e * e * e * e
            }, this.easeInOutQuart = function(e) {
                return e < .5 ? 8 * e * e * e * e : 1 - 8 * --e * e * e * e
            }, this.easeInQuint = function(e) {
                return e * e * e * e * e
            }, this.easeOutQuint = function(e) {
                return 1 + --e * e * e * e * e
            }, this.easeInOutQuint = function(e) {
                return e < .5 ? 16 * e * e * e * e * e : 1 + 16 * --e * e * e * e * e
            }
        };
        t.exports = new n
    }, {}],
    36: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = e("./AnimSystemModel"),
            a = function(e, t) {
                return void 0 === e || null === e ? t : e
            },
            o = function() {
                function e() {
                    i(this, e), this.clear()
                }
                return n(e, [{
                    key: "clear",
                    value: function() {
                        this._metrics = new WeakMap
                    }
                }, {
                    key: "destroy",
                    value: function() {
                        this._metrics = null
                    }
                }, {
                    key: "add",
                    value: function(e) {
                        var t = this._metrics.get(e);
                        if (t) return t;
                        var r = new l(e);
                        return this._metrics.set(e, r), this._refreshMetrics(e, r)
                    }
                }, {
                    key: "get",
                    value: function(e) {
                        return this._metrics.get(e)
                    }
                }, {
                    key: "refreshCollection",
                    value: function(e) {
                        var t = this;
                        e.forEach(function(e) {
                            return t._refreshMetrics(e, null)
                        })
                    }
                }, {
                    key: "refreshMetrics",
                    value: function(e) {
                        return this._refreshMetrics(e)
                    }
                }, {
                    key: "_refreshMetrics",
                    value: function(e, t) {
                        if (t = t || this._metrics.get(e), !(e instanceof Element)) return t.width = a(e.width, 0), t.height = a(e.height, 0), t.top = a(e.top, a(e.y, 0)), t.left = a(e.left, a(e.x, 0)), t.right = t.left + t.width, t.bottom = t.top + t.height, t;
                        if (void 0 === e.offsetWidth) {
                            var r = e.getBoundingClientRect();
                            return t.width = r.width, t.height = r.height, t.top = s.pageMetrics.scrollY + r.top, t.left = s.pageMetrics.scrollX + r.left, t.right = t.left + t.width, t.bottom = t.top + t.height, t
                        }
                        t.width = e.offsetWidth, t.height = e.offsetHeight, t.top = s.pageMetrics.documentOffsetY, t.left = s.pageMetrics.documentOffsetX;
                        for (var i = e; i;) t.top += i.offsetTop, t.left += i.offsetLeft, i = i.offsetParent;
                        return t.right = t.left + t.width, t.bottom = t.top + t.height, t
                    }
                }]), e
            }(),
            l = function() {
                function e(t) {
                    i(this, e), this.top = 0, this.bottom = 0, this.left = 0, this.right = 0, this.height = 0, this.width = 0
                }
                return n(e, [{
                    key: "toString",
                    value: function() {
                        return "top:" + this.top + ", bottom:" + this.bottom + ", left:" + this.left + ", right:" + this.right + ", height:" + this.height + ", width:" + this.width
                    }
                }, {
                    key: "toObject",
                    value: function() {
                        return {
                            top: this.top,
                            bottom: this.bottom,
                            left: this.left,
                            right: this.right,
                            height: this.height,
                            width: this.width
                        }
                    }
                }]), e
            }();
        t.exports = o
    }, {
        "./AnimSystemModel": 34
    }],
    37: [function(e, t, r) {
        "use strict";
        var i = e("./AnimSystemModel"),
            n = e("../Keyframes/Keyframe"),
            s = e("../Keyframes/KeyframeDiscreteEvent"),
            a = e("../Keyframes/KeyframeCSSClass"),
            o = function(e) {
                for (var t in e) {
                    var r = e[t];
                    if (i.KeyframeJSONReservedWords.indexOf(t) === -1 && Array.isArray(r)) return !0
                }
                return !1
            };
        t.exports = function(e) {
            if (void 0 !== e.cssClass || void 0 !== e.style) {
                if (o(e)) throw "CSS Keyframes cannot tween values, please use multiple keyframes instead";
                return a
            }
            if (o(e)) return n;
            if (e.event) return s;
            throw delete e.anchors, "Could not determine tween type based on " + JSON.stringify(e)
        }
    }, {
        "../Keyframes/Keyframe": 30,
        "../Keyframes/KeyframeCSSClass": 31,
        "../Keyframes/KeyframeDiscreteEvent": 33,
        "./AnimSystemModel": 34
    }],
    38: [function(e, t, r) {
        "use strict";
        t.exports = function() {
            for (var e = "", t = 0; t < 8; t++) {
                var r = 16 * Math.random() | 0;
                8 !== t && 12 !== t && 16 !== t && 20 !== t || (e += "-"), e += (12 === t ? 4 : 16 === t ? 3 & r | 8 : r).toString(16)
            }
            return e
        }
    }, {}],
    39: [function(e, t, r) {
        arguments[4][22][0].apply(r, arguments)
    }, {
        dup: 22
    }],
    40: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                return typeof e
            } : function(e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            },
            s = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            a = e("./Interpreter"),
            o = new(e("../Model/ElementMetricsLookup")),
            l = function() {
                function e(t) {
                    i(this, e), this.group = t, this.data = {
                        target: null,
                        anchors: null,
                        metrics: this.group.metrics
                    }
                }
                return s(e, [{
                    key: "parseArray",
                    value: function(e, t) {
                        return [this.parseExpression(e, t[0]), this.parseExpression(e, t[1])]
                    }
                }, {
                    key: "parseExpression",
                    value: function(t, r) {
                        if (!r) return null;
                        if ("number" == typeof r) return r;
                        if ("string" != typeof r) throw "Expression must be a string, received " + ("undefined" == typeof r ? "undefined" : n(r));
                        return this.data.target = t.controller.element, this.data.anchors = t.anchors, this.data.keyframe = t.keyframe, e._parse(r, this.data)
                    }
                }, {
                    key: "parseTimeValue",
                    value: function(e, t) {
                        if ("number" == typeof t) return t;
                        var r = this.group.expressionParser.parseExpression(e, t);
                        return this.group.convertScrollPositionToTValue(r)
                    }
                }, {
                    key: "destroy",
                    value: function() {
                        this.group = null
                    }
                }], [{
                    key: "parse",
                    value: function(t, r) {
                        return r = r || {}, r && (o.clear(), r.target && o.add(r.target), r.anchors && r.anchors.forEach(function(e) {
                            return o.add(e)
                        })), r.metrics = o, e._parse(t, r)
                    }
                }, {
                    key: "_parse",
                    value: function(e, t) {
                        return a.Parse(e).execute(t)
                    }
                }]), e
            }();
        l.programs = a.programs, window.ExpressionParser = l, t.exports = l
    }, {
        "../Model/ElementMetricsLookup": 36,
        "./Interpreter": 41
    }],
    41: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function n(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }

        function s(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = e("../Model/AnimSystemModel"),
            l = e("@marcom/sm-math-utils"),
            c = {},
            u = {
                smoothstep: function(e, t, r) {
                    return r = u.clamp((r - e) / (t - e), 0, 1), r * r * (3 - 2 * r)
                },
                deg: function(e) {
                    return 180 * e / Math.PI
                },
                rad: function(e) {
                    return e * Math.PI / 180
                },
                random: function(e, t) {
                    return Math.random() * (t - e) + e
                },
                atan: Math.atan2
            };
        Object.getOwnPropertyNames(Math).forEach(function(e) {
            return u[e] ? null : u[e.toLowerCase()] = Math[e]
        }), Object.getOwnPropertyNames(l).forEach(function(e) {
            return u[e] ? null : u[e.toLowerCase()] = l[e]
        });
        var h = null,
            m = {
                ANCHOR_CONST: "a",
                ALPHA: "ALPHA",
                LPAREN: "(",
                RPAREN: ")",
                PLUS: "PLUS",
                MINUS: "MINUS",
                MUL: "MUL",
                DIV: "DIV",
                INTEGER_CONST: "INTEGER_CONST",
                FLOAT_CONST: "FLOAT_CONST",
                COMMA: ",",
                EOF: "EOF"
            },
            f = {
                NUMBERS: /\d|\d\.\d/,
                DIGIT: /\d/,
                OPERATOR: /[-+*\/]/,
                PAREN: /[()]/,
                WHITE_SPACE: /\s/,
                ALPHA: /[a-zA-Z]|%/,
                ALPHANUMERIC: /[a-zA-Z0-9]/,
                OBJECT_UNIT: /^(t|l|b|r|%w|%h|%|h|w)$/,
                GLOBAL_METRICS_UNIT: /^(px|vh|vw)$/,
                ANY_UNIT: /^(t|l|b|r|%w|%h|%|h|w|px|vh|vw)$/,
                MATH_FUNCTION: new RegExp("\\b(" + Object.keys(u).join("|") + ")\\b", "i")
            },
            p = {
                round: 1,
                clamp: 3,
                lerp: 3,
                random: 2,
                atan: 2,
                floor: 1,
                ceil: 1,
                abs: 1,
                cos: 1,
                sin: 1,
                smoothstep: 3,
                rad: 1,
                deg: 1,
                pow: 2,
                calc: 1
            },
            d = function x(e, t) {
                s(this, x), this.type = e, this.value = t
            };
        d.ONE = new d("100", 100), d.EOF = new d(m.EOF, null);
        var v = function P(e) {
                s(this, P), this.type = e
            },
            _ = function(e) {
                function t(e, r) {
                    s(this, t);
                    var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "UnaryOp"));
                    return n.token = n.op = e, n.expr = r, n
                }
                return n(t, e), t
            }(v),
            y = function(e) {
                function t(e, r, n) {
                    s(this, t);
                    var a = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "BinOp"));
                    return a.left = e, a.op = r, a.right = n, a
                }
                return n(t, e), t
            }(v),
            b = function(e) {
                function t(e, r) {
                    s(this, t);
                    var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "MathOp"));
                    if (n.op = e, n.list = r, p[e.value] && r.length !== p[e.value]) throw new Error("Incorrect number of arguments for '" + e.value + "'. Received " + r.length + ", expected " + p[e.value]);
                    return n
                }
                return n(t, e), t
            }(v),
            g = function(e) {
                function t(e) {
                    s(this, t);
                    var r = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "Num"));
                    return r.token = e, r.value = e.value, r
                }
                return n(t, e), t
            }(v),
            E = (function(e) {
                function t(e) {
                    s(this, t);
                    var r = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "Unit"));
                    return r.token = e, r.value = e.value, r
                }
                return n(t, e), t
            }(v), function(e) {
                function t(e, r, n) {
                    s(this, t);
                    var a = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "RefValue"));
                    return a.num = e, a.ref = r, a.unit = n, a
                }
                return n(t, e), t
            }(v)),
            w = function(e) {
                function t(e, r) {
                    s(this, t);
                    var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "CSSValue"));
                    return n.ref = e, n.propertyName = r, n
                }
                return n(t, e), t
            }(v),
            A = function(e) {
                function t(e, r) {
                    s(this, t);
                    var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "PropValue"));
                    return n.ref = e, n.propertyName = r, n
                }
                return n(t, e), t
            }(v),
            S = function() {
                function e(t) {
                    s(this, e), this.text = t, this.pos = 0, this["char"] = this.text[this.pos], this.tokens = [];
                    for (var r = void 0;
                        (r = this.getNextToken()) && r !== d.EOF;) this.tokens.push(r);
                    this.tokens.push(r)
                }
                return a(e, [{
                    key: "advance",
                    value: function() {
                        this["char"] = this.text[++this.pos]
                    }
                }, {
                    key: "skipWhiteSpace",
                    value: function() {
                        for (; null != this["char"] && f.WHITE_SPACE.test(this["char"]);) this.advance()
                    }
                }, {
                    key: "name",
                    value: function() {
                        for (var e = ""; null != this["char"] && f.ALPHA.test(this["char"]);) e += this["char"], this.advance();
                        return new d(m.ALPHA, e)
                    }
                }, {
                    key: "number",
                    value: function() {
                        for (var e = ""; null != this["char"] && f.DIGIT.test(this["char"]);) e += this["char"], this.advance();
                        if (null != this["char"] && "." === this["char"]) {
                            for (e += this["char"], this.advance(); null != this["char"] && f.DIGIT.test(this["char"]);) e += this["char"], this.advance();
                            return new d(m.FLOAT_CONST, parseFloat(e))
                        }
                        return new d(m.INTEGER_CONST, parseInt(e))
                    }
                }, {
                    key: "getNextToken",
                    value: function() {
                        for (; null != this["char"];)
                            if (f.WHITE_SPACE.test(this["char"])) this.skipWhiteSpace();
                            else {
                                if (f.DIGIT.test(this["char"])) return this.number();
                                if ("," === this["char"]) return this.advance(), new d(m.COMMA, ",");
                                if (f.OPERATOR.test(this["char"])) {
                                    var e = "",
                                        t = this["char"];
                                    switch (t) {
                                        case "+":
                                            e = m.PLUS;
                                            break;
                                        case "-":
                                            e = m.MINUS;
                                            break;
                                        case "*":
                                            e = m.MUL;
                                            break;
                                        case "/":
                                            e = m.DIV
                                    }
                                    return this.advance(), new d(e, t)
                                }
                                if (f.PAREN.test(this["char"])) {
                                    var r = "",
                                        i = this["char"];
                                    switch (i) {
                                        case "(":
                                            r = m.LPAREN;
                                            break;
                                        case ")":
                                            r = m.RPAREN
                                    }
                                    return this.advance(), new d(r, i)
                                }
                                if (f.ALPHA.test(this["char"])) return this.name();
                                this.error("Unexpected character " + this["char"])
                            }
                        return d.EOF
                    }
                }]), e
            }(),
            O = function() {
                function e(t) {
                    s(this, e), this.lexer = t, this.pos = 0
                }
                return a(e, [{
                    key: "error",
                    value: function t(e) {
                        var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                            i = this.lexer.text.slice(this.pos - 3, this.pos + 3),
                            t = new Error(e + ' in "' + this.lexer.text + '" near "' + i + '". ' + r + " ");
                        throw console.error(t.message, h ? h.keyframe || h.target : ""), t
                    }
                }, {
                    key: "consume",
                    value: function(e) {
                        var t = this.currentToken;
                        return t.type === e ? this.pos += 1 : this.error("Invalid token " + this.currentToken.value + ", expected " + e), t
                    }
                }, {
                    key: "consumeList",
                    value: function(e) {
                        e.includes(this.currentToken) ? this.pos += 1 : this.error("Invalid token " + this.currentToken.value + ", expected " + tokenType)
                    }
                }, {
                    key: "expr",
                    value: function() {
                        for (var e = this.term(); this.currentToken.type === m.PLUS || this.currentToken.type === m.MINUS;) {
                            var t = this.currentToken;
                            switch (t.value) {
                                case "+":
                                    this.consume(m.PLUS);
                                    break;
                                case "-":
                                    this.consume(m.MINUS)
                            }
                            e = new y(e, t, this.term())
                        }
                        return e
                    }
                }, {
                    key: "term",
                    value: function() {
                        for (var e = this.factor(); this.currentToken.type === m.MUL || this.currentToken.type === m.DIV;) {
                            var t = this.currentToken;
                            switch (t.value) {
                                case "*":
                                    this.consume(m.MUL);
                                    break;
                                case "/":
                                    this.consume(m.DIV)
                            }
                            e = new y(e, t, this.factor())
                        }
                        return e
                    }
                }, {
                    key: "factor",
                    value: function() {
                        if (this.currentToken.type === m.PLUS) return new _(this.consume(m.PLUS), this.factor());
                        if (this.currentToken.type === m.MINUS) return new _(this.consume(m.MINUS), this.factor());
                        if (this.currentToken.type === m.INTEGER_CONST || this.currentToken.type === m.FLOAT_CONST) {
                            var e = new g(this.currentToken);
                            if (this.pos += 1, f.OPERATOR.test(this.currentToken.value) || this.currentToken.type === m.RPAREN || this.currentToken.type === m.COMMA || this.currentToken.type === m.EOF) return e;
                            if (this.currentToken.type === m.ALPHA && this.currentToken.value === m.ANCHOR_CONST) return this.consume(m.ALPHA), new E(e, this.anchorIndex(), this.unit(f.ANY_UNIT));
                            if (this.currentToken.type === m.ALPHA) return "%a" === this.currentToken.value && this.error("%a is invalid, try removing the %"), new E(e, null, this.unit());
                            this.error("Expected a scaling unit type", "Such as 'h' / 'w'")
                        } else {
                            if (f.OBJECT_UNIT.test(this.currentToken.value)) return new E(new g(d.ONE), null, this.unit());
                            if (this.currentToken.value === m.ANCHOR_CONST) {
                                this.consume(m.ALPHA);
                                var t = this.anchorIndex();
                                if (f.OBJECT_UNIT.test(this.currentToken.value)) return new E(new g(d.ONE), t, this.unit())
                            } else if (this.currentToken.type === m.ALPHA) {
                                if ("css" === this.currentToken.value || "prop" === this.currentToken.value) {
                                    var r = "css" === this.currentToken.value ? w : A;
                                    this.consume(m.ALPHA), this.consume(m.LPAREN);
                                    var i = this.propertyName(),
                                        n = null;
                                    return this.currentToken.type === m.COMMA && (this.consume(m.COMMA), this.consume(m.ALPHA), n = this.anchorIndex()), this.consume(m.RPAREN), new r(n, i)
                                }
                                if (f.MATH_FUNCTION.test(this.currentToken.value)) {
                                    var s = this.currentToken.value.toLowerCase();
                                    if ("number" == typeof u[s]) return this.consume(m.ALPHA), new g(new d(m.ALPHA, u[s]));
                                    var a = d[s] || new d(s, s),
                                        o = [];
                                    this.consume(m.ALPHA), this.consume(m.LPAREN);
                                    var l = null;
                                    do this.currentToken.value === m.COMMA && this.consume(m.COMMA), l = this.expr(), o.push(l); while (this.currentToken.value === m.COMMA);
                                    return this.consume(m.RPAREN), new b(a, o)
                                }
                            } else if (this.currentToken.type === m.LPAREN) {
                                this.consume(m.LPAREN);
                                var c = this.expr();
                                return this.consume(m.RPAREN), c
                            }
                        }
                        this.error("Unexpected token " + this.currentToken.value)
                    }
                }, {
                    key: "propertyName",
                    value: function() {
                        for (var e = ""; this.currentToken.type === m.ALPHA || this.currentToken.type === m.MINUS;) e += this.currentToken.value, this.pos += 1;
                        return e
                    }
                }, {
                    key: "unit",
                    value: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : f.ANY_UNIT,
                            t = this.currentToken;
                        return t.type === m.ALPHA && e.test(t.value) ? (this.consume(m.ALPHA), new d(m.ALPHA, t.value = t.value.replace(/%(h|w)/, "$1").replace("%", "h"))) : void this.error("Expected unit type")
                    }
                }, {
                    key: "anchorIndex",
                    value: function() {
                        var e = this.currentToken;
                        return e.type === m.INTEGER_CONST ? (this.consume(m.INTEGER_CONST), new g(e)) : void this.error("Invalid anchor reference", ". Should be something like a0, a1, a2")
                    }
                }, {
                    key: "parse",
                    value: function() {
                        var e = this.expr();
                        return this.currentToken !== d.EOF && this.error("Unexpected token " + this.currentToken.value), e
                    }
                }, {
                    key: "currentToken",
                    get: function() {
                        return this.lexer.tokens[this.pos]
                    }
                }]), e
            }(),
            k = function() {
                function e(t) {
                    s(this, e), this.parser = t, this.root = t.parse()
                }
                return a(e, [{
                    key: "visit",
                    value: function(e) {
                        var t = this[e.type];
                        if (!t) throw new Error("No visit method named, " + t);
                        var r = t.call(this, e);
                        return r
                    }
                }, {
                    key: "BinOp",
                    value: function(e) {
                        switch (e.op.type) {
                            case m.PLUS:
                                return this.visit(e.left) + this.visit(e.right);
                            case m.MINUS:
                                return this.visit(e.left) - this.visit(e.right);
                            case m.MUL:
                                return this.visit(e.left) * this.visit(e.right);
                            case m.DIV:
                                return this.visit(e.left) / this.visit(e.right)
                        }
                    }
                }, {
                    key: "RefValue",
                    value: function(e) {
                        var t = this.unwrapReference(e),
                            r = e.unit.value,
                            i = e.num.value,
                            n = h.metrics.get(t);
                        switch (r) {
                            case "h":
                                return .01 * i * n.height;
                            case "t":
                                return .01 * i * n.top;
                            case "vh":
                                return .01 * i * o.pageMetrics.windowHeight;
                            case "vw":
                                return .01 * i * o.pageMetrics.windowWidth;
                            case "px":
                                return i;
                            case "w":
                                return .01 * i * n.width;
                            case "b":
                                return .01 * i * n.bottom;
                            case "l":
                                return .01 * i * n.left;
                            case "r":
                                return .01 * i * n.right
                        }
                    }
                }, {
                    key: "PropValue",
                    value: function(e) {
                        var t = null === e.ref ? h.target : h.anchors[e.ref.value];
                        return t[e.propertyName]
                    }
                }, {
                    key: "CSSValue",
                    value: function(t) {
                        var r = this.unwrapReference(t),
                            i = getComputedStyle(r).getPropertyValue(t.propertyName);
                        return "" === i ? 0 : e.Parse(i).execute(h)
                    }
                }, {
                    key: "Num",
                    value: function(e) {
                        return e.value
                    }
                }, {
                    key: "UnaryOp",
                    value: function(e) {
                        return e.op.type === m.PLUS ? +this.visit(e.expr) : e.op.type === m.MINUS ? -this.visit(e.expr) : void 0
                    }
                }, {
                    key: "MathOp",
                    value: function(e) {
                        var t = this,
                            r = e.list.map(function(e) {
                                return t.visit(e)
                            });
                        return u[e.op.value].apply(null, r)
                    }
                }, {
                    key: "unwrapReference",
                    value: function(e) {
                        return null === e.ref ? h.target : (e.ref.value >= h.anchors.length && console.error("Not enough anchors supplied for expression " + this.parser.lexer.text, h.target), h.anchors[e.ref.value])
                    }
                }, {
                    key: "execute",
                    value: function(e) {
                        return h = e, this.visit(this.root)
                    }
                }], [{
                    key: "Parse",
                    value: function(t) {
                        return c[t] || (c[t] = new e(new O(new S(t))))
                    }
                }]), e
            }();
        k.programs = c, t.exports = k
    }, {
        "../Model/AnimSystemModel": 34,
        "@marcom/sm-math-utils": 68
    }],
    42: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = function _(e, t, r) {
                null === e && (e = Function.prototype);
                var i = Object.getOwnPropertyDescriptor(e, t);
                if (void 0 === i) {
                    var n = Object.getPrototypeOf(e);
                    return null === n ? void 0 : _(n, t, r)
                }
                if ("value" in i) return i.value;
                var s = i.get;
                if (void 0 !== s) return s.call(r)
            },
            l = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            c = e("@marcom/sm-math-utils"),
            u = e("./utils/arrayToObject"),
            h = e("./Model/AnimSystemModel"),
            m = e("./Model/ElementMetricsLookup"),
            f = e("./Parsing/ExpressionParser"),
            p = e("./Keyframes/KeyframeController"),
            d = {
                create: e("@marcom/ac-raf-emitter/RAFEmitter"),
                update: e("@marcom/ac-raf-emitter/update"),
                draw: e("@marcom/ac-raf-emitter/draw")
            },
            v = function(e) {
                function t(e, r) {
                    i(this, t);
                    var s = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return s.anim = r, s.element = e, s.name = s.name || e.getAttribute("data-anim-scroll-group"), s.isEnabled = !0, s.position = new h.Progress, s.metrics = new m, s.metrics.add(s.element), s.expressionParser = new f(s), s.boundsMin = 0, s.boundsMax = 0, s.timelineUpdateRequired = !1, s._keyframesDirty = !1, s.viewableRange = s.createViewableRange(), s.defaultEase = h.KeyframeDefaults.ease, s.keyframeControllers = [], s.updateProgress(s.getPosition()), s.onDOMRead = s.onDOMRead.bind(s), s.onDOMWrite = s.onDOMWrite.bind(s), s.gui = null, s.finalizeInit(), s
                }
                return s(t, e), a(t, [{
                    key: "finalizeInit",
                    value: function() {
                        this.element._animInfo = new h.AnimInfo(this, null, (!0)), this.setupRAFEmitter()
                    }
                }, {
                    key: "destroy",
                    value: function() {
                        this.expressionParser.destroy(), this.expressionParser = null;
                        for (var e = 0, r = this.keyframeControllers.length; e < r; e++) this.keyframeControllers[e].destroy();
                        this.keyframeControllers = null, this.position = null, this.viewableRange = null, this.gui && (this.gui.destroy(), this.gui = null), this.metrics.destroy(), this.metrics = null, this.rafEmitter.destroy(), this.rafEmitter = null, this.anim = null, this.element._animInfo && this.element._animInfo.group === this && (this.element._animInfo.group = null, this.element._animInfo = null), this.element = null, this.isEnabled = !1, o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                    }
                }, {
                    key: "removeKeyframeController",
                    value: function(e) {
                        var t = this;
                        if (!this.keyframeControllers.includes(e)) return Promise.resolve();
                        var r = e._allKeyframes;
                        return e._allKeyframes = [], this.keyframesDirty = !0, new Promise(function(i) {
                            d.draw(function() {
                                var n = t.keyframeControllers.indexOf(e);
                                return n === -1 ? void i() : (t.keyframeControllers.splice(n, 1), e.onDOMWrite(), r.forEach(function(e) {
                                    return e.destroy()
                                }), e.destroy(), t.gui && t.gui.create(), void i())
                            })
                        })
                    }
                }, {
                    key: "remove",
                    value: function() {
                        return this.anim.removeGroup(this)
                    }
                }, {
                    key: "setupRAFEmitter",
                    value: function(e) {
                        var t = this;
                        this.rafEmitter && this.rafEmitter.destroy(), this.rafEmitter = e || new d.create, this.rafEmitter.on("update", this.onDOMRead), this.rafEmitter.on("draw", this.onDOMWrite), this.rafEmitter.once("external", function() {
                            return t.reconcile()
                        })
                    }
                }, {
                    key: "requestDOMChange",
                    value: function() {
                        return !!this.isEnabled && this.rafEmitter.run()
                    }
                }, {
                    key: "onDOMRead",
                    value: function() {
                        this.keyframesDirty && this.onKeyframesDirty();
                        for (var e = 0, t = this.keyframeControllers.length; e < t; e++) this.keyframeControllers[e].onDOMRead(this.position)
                    }
                }, {
                    key: "onDOMWrite",
                    value: function() {
                        for (var e = 0, t = this.keyframeControllers.length; e < t; e++) this.keyframeControllers[e].onDOMWrite(this.position);
                        this.needsUpdate() && this.requestDOMChange()
                    }
                }, {
                    key: "needsUpdate",
                    value: function() {
                        if (this._keyframesDirty) return !0;
                        for (var e = 0, t = this.keyframeControllers.length; e < t; e++)
                            if (this.keyframeControllers[e].needsUpdate()) return !0;
                        return !1
                    }
                }, {
                    key: "addKeyframe",
                    value: function(e, t) {
                        var r = this.getControllerForTarget(e);
                        return null === r && (r = new p(this, e), this.keyframeControllers.push(r)), this.keyframesDirty = !0, r.addKeyframe(t)
                    }
                }, {
                    key: "forceUpdate",
                    value: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            t = e.waitForNextUpdate,
                            r = void 0 === t || t,
                            i = e.silent,
                            n = void 0 !== i && i;
                        this.isEnabled && (this.refreshMetrics(), this.timelineUpdateRequired = !0, r ? this.keyframesDirty = !0 : this.onKeyframesDirty({
                            silent: n
                        }))
                    }
                }, {
                    key: "onKeyframesDirty",
                    value: function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            t = e.silent,
                            r = void 0 !== t && t;
                        this.determineActiveKeyframes(), this.keyframesDirty = !1, this.metrics.refreshMetrics(this.element), this.viewableRange = this.createViewableRange();
                        for (var i = 0, n = this.keyframeControllers.length; i < n; i++) this.keyframeControllers[i].updateAnimationConstraints();
                        this.updateBounds(), this.updateProgress(this.getPosition()), r || this._onScroll(), this.gui && this.gui.create()
                    }
                }, {
                    key: "refreshMetrics",
                    value: function() {
                        var e = new Set([this.element]);
                        this.keyframeControllers.forEach(function(t) {
                            e.add(t.element), t._allKeyframes.forEach(function(t) {
                                return t.anchors.forEach(function(t) {
                                    return e.add(t)
                                })
                            })
                        }), this.metrics.refreshCollection(e), this.viewableRange = this.createViewableRange()
                    }
                }, {
                    key: "reconcile",
                    value: function() {
                        for (var e = 0, t = this.keyframeControllers.length; e < t; e++) this.keyframeControllers[e].reconcile()
                    }
                }, {
                    key: "determineActiveKeyframes",
                    value: function(e) {
                        e = e || u(Array.from(document.documentElement.classList));
                        for (var t = 0, r = this.keyframeControllers.length; t < r; t++) this.keyframeControllers[t].determineActiveKeyframes(e)
                    }
                }, {
                    key: "updateBounds",
                    value: function() {
                        if (0 === this.keyframeControllers.length) return this.boundsMin = 0, void(this.boundsMax = 0);
                        for (var e = {
                                min: Number.POSITIVE_INFINITY,
                                max: Number.NEGATIVE_INFINITY
                            }, t = 0, r = this.keyframeControllers.length; t < r; t++) this.keyframeControllers[t].getBounds(e);
                        var i = this.convertTValueToScrollPosition(e.min),
                            n = this.convertTValueToScrollPosition(e.max);
                        n - i < h.pageMetrics.windowHeight ? (e.min = this.convertScrollPositionToTValue(i - .5 * h.pageMetrics.windowHeight), e.max = this.convertScrollPositionToTValue(n + .5 * h.pageMetrics.windowHeight)) : (e.min -= .001, e.max += .001), this.boundsMin = e.min, this.boundsMax = e.max, this.timelineUpdateRequired = !0
                    }
                }, {
                    key: "createViewableRange",
                    value: function() {
                        return new h.ViewableRange(this.metrics.get(this.element), h.pageMetrics.windowHeight)
                    }
                }, {
                    key: "_onBreakpointChange",
                    value: function(e, t) {
                        this.keyframesDirty = !0, this.determineActiveKeyframes()
                    }
                }, {
                    key: "updateProgress",
                    value: function(e) {
                        return this.hasDuration() ? (this.position.localUnclamped = (e - this.viewableRange.a) / (this.viewableRange.d - this.viewableRange.a), void(this.position.local = c.clamp(this.position.localUnclamped, this.boundsMin, this.boundsMax))) : void(this.position.local = this.position.localUnclamped = 0)
                    }
                }, {
                    key: "performTimelineDispatch",
                    value: function() {
                        for (var e = 0, t = this.keyframeControllers.length; e < t; e++) this.keyframeControllers[e].updateLocalProgress(this.position.local);
                        this.trigger(h.EVENTS.ON_TIMELINE_UPDATE, this.position.local), this.timelineUpdateRequired = !1, this.position.lastPosition !== this.position.local && (this.position.lastPosition <= this.boundsMin && this.position.localUnclamped > this.boundsMin ? this.trigger(h.EVENTS.ON_TIMELINE_START, this) : this.position.lastPosition >= this.boundsMin && this.position.localUnclamped < this.boundsMin ? this.trigger(h.EVENTS.ON_TIMELINE_START + ":reverse", this) : this.position.lastPosition <= this.boundsMax && this.position.localUnclamped >= this.boundsMax ? this.trigger(h.EVENTS.ON_TIMELINE_COMPLETE, this) : this.position.lastPosition >= this.boundsMax && this.position.localUnclamped < this.boundsMax && this.trigger(h.EVENTS.ON_TIMELINE_COMPLETE + ":reverse", this)), null !== this.gui && this.gui.onScrollUpdate(this.position)
                    }
                }, {
                    key: "_onScroll",
                    value: function(e) {
                        if (!this.isEnabled) return !1;
                        void 0 === e && (e = this.getPosition()), this.updateProgress(e);
                        var t = this.position.lastPosition === this.boundsMin || this.position.lastPosition === this.boundsMax,
                            r = this.position.localUnclamped === this.boundsMin || this.position.localUnclamped === this.boundsMax;
                        if (!this.timelineUpdateRequired && t && r && this.position.lastPosition === e) return void(this.position.local = this.position.localUnclamped);
                        if (this.timelineUpdateRequired || this.position.localUnclamped > this.boundsMin && this.position.localUnclamped < this.boundsMax) return this.performTimelineDispatch(), this.requestDOMChange(), void(this.position.lastPosition = this.position.localUnclamped);
                        var i = this.position.lastPosition > this.boundsMin && this.position.lastPosition < this.boundsMax,
                            n = this.position.localUnclamped <= this.boundsMin || this.position.localUnclamped >= this.boundsMax;
                        if (i && n) return this.performTimelineDispatch(), this.requestDOMChange(), void(this.position.lastPosition = this.position.localUnclamped);
                        var s = this.position.lastPosition < this.boundsMin && this.position.localUnclamped > this.boundsMax,
                            a = this.position.lastPosition > this.boundsMax && this.position.localUnclamped < this.boundsMax;
                        (s || a) && (this.performTimelineDispatch(), this.requestDOMChange(), this.position.lastPosition = this.position.localUnclamped), null !== this.gui && this.gui.onScrollUpdate(this.position)
                    }
                }, {
                    key: "convertScrollPositionToTValue",
                    value: function(e) {
                        return this.hasDuration() ? c.map(e, this.viewableRange.a, this.viewableRange.d, 0, 1) : 0
                    }
                }, {
                    key: "convertTValueToScrollPosition",
                    value: function(e) {
                        return this.hasDuration() ? c.map(e, 0, 1, this.viewableRange.a, this.viewableRange.d) : 0
                    }
                }, {
                    key: "hasDuration",
                    value: function() {
                        return this.viewableRange.a !== this.viewableRange.d
                    }
                }, {
                    key: "getPosition",
                    value: function() {
                        return h.pageMetrics.scrollY
                    }
                }, {
                    key: "getControllerForTarget",
                    value: function(e) {
                        if (!e._animInfo || !e._animInfo.controllers) return null;
                        if (e._animInfo.controller && e._animInfo.controller.group === this) return e._animInfo.controller;
                        for (var t = e._animInfo.controllers, r = 0, i = t.length; r < i; r++)
                            if (t[r].group === this) return t[r];
                        return null
                    }
                }, {
                    key: "trigger",
                    value: function(e, t) {
                        if ("undefined" != typeof this._events[e])
                            for (var r = this._events[e].length - 1; r >= 0; r--) void 0 !== t ? this._events[e][r](t) : this._events[e][r]()
                    }
                }, {
                    key: "keyframesDirty",
                    set: function(e) {
                        this._keyframesDirty = e, this._keyframesDirty && this.requestDOMChange()
                    },
                    get: function() {
                        return this._keyframesDirty
                    }
                }]), t
            }(l);
        t.exports = v
    }, {
        "./Keyframes/KeyframeController": 32,
        "./Model/AnimSystemModel": 34,
        "./Model/ElementMetricsLookup": 36,
        "./Parsing/ExpressionParser": 40,
        "./utils/arrayToObject": 44,
        "@marcom/ac-event-emitter-micro": 4,
        "@marcom/ac-raf-emitter/RAFEmitter": 8,
        "@marcom/ac-raf-emitter/draw": 14,
        "@marcom/ac-raf-emitter/update": 18,
        "@marcom/sm-math-utils": 68
    }],
    43: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = function f(e, t, r) {
                null === e && (e = Function.prototype);
                var i = Object.getOwnPropertyDescriptor(e, t);
                if (void 0 === i) {
                    var n = Object.getPrototypeOf(e);
                    return null === n ? void 0 : f(n, t, r)
                }
                if ("value" in i) return i.value;
                var s = i.get;
                if (void 0 !== s) return s.call(r)
            },
            l = e("./ScrollGroup"),
            c = e("@marcom/sm-math-utils"),
            u = 0,
            h = {
                create: e("@marcom/ac-raf-emitter/RAFEmitter")
            },
            m = function(e) {
                function t(e, r) {
                    i(this, t), e || (e = document.createElement("div"), e.className = "TimeGroup-" + u++);
                    var s = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e, r));
                    return s.name = s.name || e.getAttribute("data-anim-time-group"), s._isPaused = !0, s._repeats = 0, s._isReversed = !1, s._timeScale = 1, s
                }
                return s(t, e), a(t, [{
                    key: "finalizeInit",
                    value: function() {
                        if (!this.anim) throw "TimeGroup not instantiated correctly. Please use `AnimSystem.createTimeGroup(el)`";
                        this.defaultEase = 1, this.onPlayTimeUpdate = this.onPlayTimeUpdate.bind(this), o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "finalizeInit", this).call(this)
                    }
                }, {
                    key: "progress",
                    value: function(e) {
                        if (void 0 === e) return 0 === this.boundsMax ? 0 : this.position.local / this.boundsMax;
                        var t = e * this.boundsMax;
                        this.timelineUpdateRequired = !0, this._onScroll(t)
                    }
                }, {
                    key: "time",
                    value: function(e) {
                        return void 0 === e ? this.position.local : (e = c.clamp(e, this.boundsMin, this.boundsMax), this.timelineUpdateRequired = !0, void this._onScroll(e))
                    }
                }, {
                    key: "play",
                    value: function(e) {
                        this.reversed(!1), this.isEnabled = !0, this._isPaused = !1, this.time(e), this._playheadEmitter.run()
                    }
                }, {
                    key: "reverse",
                    value: function(e) {
                        this.reversed(!0), this.isEnabled = !0, this._isPaused = !1, this.time(e), this._playheadEmitter.run()
                    }
                }, {
                    key: "reversed",
                    value: function(e) {
                        return void 0 === e ? this._isReversed : void(this._isReversed = e)
                    }
                }, {
                    key: "restart",
                    value: function() {
                        this._isReversed ? (this.progress(1), this.reverse(this.time())) : (this.progress(0), this.play(this.time()))
                    }
                }, {
                    key: "pause",
                    value: function(e) {
                        this.time(e), this._isPaused = !0
                    }
                }, {
                    key: "paused",
                    value: function(e) {
                        return void 0 === e ? this._isPaused : (this._isPaused = e, this._isPaused || this.play(), this)
                    }
                }, {
                    key: "onPlayTimeUpdate",
                    value: function(e) {
                        if (!this._isPaused) {
                            var r = c.clamp(e.delta / 1e3, 0, .5);
                            this._isReversed && (r = -r);
                            var i = this.time(),
                                n = i + r * this._timeScale;
                            if (this._repeats === t.REPEAT_FOREVER || this._repeats > 0) {
                                var s = !1;
                                !this._isReversed && n > this.boundsMax ? (n -= this.boundsMax, s = !0) : this._isReversed && n < 0 && (n = this.boundsMax + n, s = !0), s && (this._repeats = this._repeats === t.REPEAT_FOREVER ? t.REPEAT_FOREVER : this._repeats - 1)
                            }
                            this.time(n);
                            var a = !this._isReversed && this.position.local !== this.duration,
                                o = this._isReversed && 0 !== this.position.local;
                            a || o ? this._playheadEmitter.run() : this.paused(!0)
                        }
                    }
                }, {
                    key: "updateProgress",
                    value: function(e) {
                        return this.hasDuration() ? (this.position.localUnclamped = e, void(this.position.local = c.clamp(this.position.localUnclamped, this.boundsMin, this.boundsMax))) : void(this.position.local = this.position.localUnclamped = 0)
                    }
                }, {
                    key: "updateBounds",
                    value: function() {
                        if (0 === this.keyframeControllers.length) return this.boundsMin = 0, void(this.boundsMax = 0);
                        for (var e = {
                                min: Number.POSITIVE_INFINITY,
                                max: Number.NEGATIVE_INFINITY
                            }, t = 0, r = this.keyframeControllers.length; t < r; t++) this.keyframeControllers[t].getBounds(e);
                        this.boundsMin = 0, this.boundsMax = e.max, this.viewableRange.a = this.viewableRange.b = 0, this.viewableRange.c = this.viewableRange.d = this.boundsMax, this.timelineUpdateRequired = !0
                    }
                }, {
                    key: "setupRAFEmitter",
                    value: function(e) {
                        this._playheadEmitter = new h.create, this._playheadEmitter.on("update", this.onPlayTimeUpdate), o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "setupRAFEmitter", this).call(this, e)
                    }
                }, {
                    key: "timeScale",
                    value: function(e) {
                        return void 0 === e ? this._timeScale : (this._timeScale = e, this)
                    }
                }, {
                    key: "repeats",
                    value: function(e) {
                        return void 0 === e ? this._repeats : void(this._repeats = e)
                    }
                }, {
                    key: "getPosition",
                    value: function() {
                        return this.position.local
                    }
                }, {
                    key: "convertScrollPositionToTValue",
                    value: function(e) {
                        return e
                    }
                }, {
                    key: "convertTValueToScrollPosition",
                    value: function(e) {
                        return e
                    }
                }, {
                    key: "hasDuration",
                    value: function() {
                        return this.duration > 0
                    }
                }, {
                    key: "destroy",
                    value: function() {
                        this._playheadEmitter.destroy(), this._playheadEmitter = null, o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                    }
                }, {
                    key: "duration",
                    get: function() {
                        return this.keyframesDirty && this.onKeyframesDirty({
                            silent: !0
                        }), this.boundsMax
                    }
                }]), t
            }(l);
        m.REPEAT_FOREVER = -1, t.exports = m
    }, {
        "./ScrollGroup": 42,
        "@marcom/ac-raf-emitter/RAFEmitter": 8,
        "@marcom/sm-math-utils": 68
    }],
    44: [function(e, t, r) {
        "use strict";
        var i = function(e) {
            return e.reduce(function(e, t) {
                return e[t] = t, e
            }, {})
        };
        t.exports = i
    }, {}],
    45: [function(e, t, r) {
        "use strict";
        t.exports = function(e, t) {
            if ("string" != typeof e) return e;
            try {
                return (t || document).querySelector(e) || document.querySelector(e)
            } catch (r) {
                return !1
            }
        }
    }, {}],
    46: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = function p(e, t, r) {
                null === e && (e = Function.prototype);
                var i = Object.getOwnPropertyDescriptor(e, t);
                if (void 0 === i) {
                    var n = Object.getPrototypeOf(e);
                    return null === n ? void 0 : p(n, t, r)
                }
                if ("value" in i) return i.value;
                var s = i.get;
                if (void 0 !== s) return s.call(r)
            },
            l = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            c = e("@marcom/anim-system/Model/AnimSystemModel"),
            u = {
                create: e("@marcom/ac-raf-emitter/RAFEmitter"),
                update: e("@marcom/ac-raf-emitter/update"),
                draw: e("@marcom/ac-raf-emitter/draw")
            },
            h = function() {},
            m = 0,
            f = function(e) {
                function t(e) {
                    i(this, t);
                    var r = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return r.el = e.el, r.gum = e.gum, r.componentName = e.componentName, r._keyframeController = null, r
                }
                return s(t, e), a(t, [{
                    key: "destroy",
                    value: function() {
                        this.el = null, this.gum = null, this._keyframeController = null, o(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "destroy", this).call(this)
                    }
                }, {
                    key: "addKeyframe",
                    value: function(e) {
                        var t = e.el || this.el;
                        return (e.group || this.anim).addKeyframe(t, e)
                    }
                }, {
                    key: "addDiscreteEvent",
                    value: function(e) {
                        e.event = e.event || "Generic-Event-Name-" + m++;
                        var t = void 0 !== e.end && e.end !== e.start,
                            r = this.addKeyframe(e);
                        return t ? (e.onEnterOnce && r.controller.once(e.event + ":enter", e.onEnterOnce), e.onExitOnce && r.controller.once(e.event + ":exit", e.onExitOnce), e.onEnter && r.controller.on(e.event + ":enter", e.onEnter), e.onExit && r.controller.on(e.event + ":exit", e.onExit)) : (e.onEventOnce && r.controller.once(e.event, e.onEventOnce), e.onEventReverseOnce && r.controller.once(e.event + ":reverse", e.onEventReverseOnce), e.onEvent && r.controller.on(e.event, e.onEvent), e.onEventReverse && r.controller.on(e.event + ":reverse", e.onEventReverse)), r
                    }
                }, {
                    key: "addRAFLoop",
                    value: function(e) {
                        var t = ["start", "end"];
                        if (!t.every(function(t) {
                                return e.hasOwnProperty(t)
                            })) return void console.log("BubbleGum.BaseComponent::addRAFLoop required options are missing: " + t.join(" "));
                        var r = new u.create;
                        r.on("update", e.onUpdate || h), r.on("draw", e.onDraw || h), r.on("draw", function() {
                            return r.run()
                        });
                        var i = e.onEnter,
                            n = e.onExit;
                        return e.onEnter = function() {
                            r.run(), i ? i() : 0
                        }, e.onExit = function() {
                            r.cancel(), n ? n() : 0
                        }, this.addDiscreteEvent(e)
                    }
                }, {
                    key: "addContinuousEvent",
                    value: function(e) {
                        e.onDraw || console.log("BubbleGum.BaseComponent::addContinuousEvent required option `onDraw` is missing. Consider using a regular keyframe if you do not need a callback"), e.event = e.event || "Generic-Event-Name-" + m++;
                        var t = this.addKeyframe(e);
                        return t.controller.on(e.event, e.onDraw), t
                    }
                }, {
                    key: "mounted",
                    value: function() {}
                }, {
                    key: "onResizeImmediate",
                    value: function(e) {}
                }, {
                    key: "onResizeDebounced",
                    value: function(e) {}
                }, {
                    key: "onBreakpointChange",
                    value: function(e) {}
                }, {
                    key: "anim",
                    get: function() {
                        return this.gum.anim
                    }
                }, {
                    key: "keyframeController",
                    get: function() {
                        return this._keyframeController || (this._keyframeController = this.anim.getControllerForTarget(this.el))
                    }
                }, {
                    key: "pageMetrics",
                    get: function() {
                        return c.pageMetrics
                    }
                }]), t
            }(l);
        t.exports = f
    }, {
        "@marcom/ac-event-emitter-micro": 4,
        "@marcom/ac-raf-emitter/RAFEmitter": 8,
        "@marcom/ac-raf-emitter/draw": 14,
        "@marcom/ac-raf-emitter/update": 18,
        "@marcom/anim-system/Model/AnimSystemModel": 34
    }],
    47: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }

        function n(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }

        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        var a = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            o = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            l = e("@marcom/delayed-initializer"),
            c = e("@marcom/anim-system"),
            u = e("@marcom/anim-system/Model/AnimSystemModel"),
            h = e("./ComponentMap"),
            m = {},
            f = function(e) {
                function t(e) {
                    i(this, t);
                    var r = n(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                    return r.el = e, r.anim = c, r.components = [], r.el.getAttribute("data-anim-scroll-group") || r.el.setAttribute("data-anim-scroll-group", "bubble-gum-group"), c.on(u.EVENTS.ON_DOM_GROUPS_CREATED, function(e) {
                        r.componentsInitialized = !1, r.initComponents(), r.setupEvents()
                    }), c.on(u.EVENTS.ON_DOM_KEYFRAMES_CREATED, function() {
                        r.components.forEach(function(e) {
                            return e.mounted()
                        }), r.trigger(t.EVENTS.DOM_COMPONENTS_MOUNTED)
                    }), l.add(function() {
                        return c.initialize()
                    }), r
                }
                return s(t, e), a(t, [{
                    key: "initComponents",
                    value: function() {
                        var e = Array.prototype.slice.call(this.el.querySelectorAll("[data-component-list]"));
                        this.el.hasAttribute("data-component-list") && e.push(this.el);
                        for (var t = 0; t < e.length; t++)
                            for (var r = e[t], i = r.getAttribute("data-component-list"), n = i.split(" "), s = 0, a = n.length; s < a; s++) {
                                var o = n[s];
                                "" !== o && " " !== o && this.addComponent({
                                    el: r,
                                    componentName: o
                                })
                            }
                        this.componentsInitialized = !0
                    }
                }, {
                    key: "setupEvents",
                    value: function() {
                        this.onResizeDebounced = this.onResizeDebounced.bind(this), this.onResizeImmediate = this.onResizeImmediate.bind(this), this.onBreakpointChange = this.onBreakpointChange.bind(this), c.on(u.PageEvents.ON_RESIZE_IMMEDIATE, this.onResizeImmediate), c.on(u.PageEvents.ON_RESIZE_DEBOUNCED, this.onResizeDebounced), c.on(u.PageEvents.ON_BREAKPOINT_CHANGE, this.onBreakpointChange)
                    }
                }, {
                    key: "addComponent",
                    value: function(e) {
                        var r = e.el,
                            i = e.componentName,
                            n = e.data;
                        if (!h.hasOwnProperty(i)) throw "BubbleGum::addComponent could not add component to '" + r.className + "'. No component type '" + i + "' found!";
                        var s = h[i];
                        if (!t.componentIsSupported(s, i)) return void 0 === m[i] && (console.log("BubbleGum::addComponent unsupported component '" + i + "'. Reason: '" + i + ".IS_SUPPORTED' returned false"), m[i] = !0), null;
                        var a = r.dataset.componentList || "";
                        a.includes(i) || (r.dataset.componentList = a.split(" ").concat(i).join(" "));
                        var o = new s({
                            el: r,
                            data: n,
                            componentName: e.componentName,
                            gum: this,
                            pageMetrics: u.pageMetrics
                        });
                        return this.components.push(o), this.componentsInitialized && o.mounted(), o
                    }
                }, {
                    key: "removeComponent",
                    value: function(e) {
                        var t = this.components.indexOf(e);
                        t !== -1 && (this.components.splice(t, 1), e.el.dataset.componentList = e.el.dataset.componentList.split(" ").filter(function(t) {
                            return t !== e.componentName
                        }).join(" "), e.destroy())
                    }
                }, {
                    key: "getComponentOfType",
                    value: function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document.documentElement,
                            r = "[data-component-list*=" + e + "]",
                            i = t.matches(r) ? t : t.querySelector(r);
                        return i ? this.components.find(function(t) {
                            return t instanceof h[e] && t.el === i
                        }) : null
                    }
                }, {
                    key: "getComponentsOfType",
                    value: function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : document.documentElement,
                            r = "[data-component-list*=" + e + "]",
                            i = t.matches(r) ? [t] : Array.from(t.querySelectorAll(r));
                        return this.components.filter(function(t) {
                            return t instanceof h[e] && i.includes(t.el)
                        })
                    }
                }, {
                    key: "getComponentsForElement",
                    value: function(e) {
                        return this.components.filter(function(t) {
                            return t.el === e
                        })
                    }
                }, {
                    key: "onResizeImmediate",
                    value: function() {
                        this.components.forEach(function(e) {
                            return e.onResizeImmediate(u.pageMetrics)
                        })
                    }
                }, {
                    key: "onResizeDebounced",
                    value: function() {
                        this.components.forEach(function(e) {
                            return e.onResizeDebounced(u.pageMetrics)
                        })
                    }
                }, {
                    key: "onBreakpointChange",
                    value: function() {
                        this.components.forEach(function(e) {
                            return e.onBreakpointChange(u.pageMetrics)
                        })
                    }
                }], [{
                    key: "componentIsSupported",
                    value: function(e, t) {
                        var r = e.IS_SUPPORTED;
                        if (void 0 === r) return !0;
                        if ("function" != typeof r) return console.error('BubbleGum::addComponent error in "' + t + '".IS_SUPPORTED - it should be a function which returns true/false'), !0;
                        var i = e.IS_SUPPORTED();
                        return void 0 === i ? (console.error('BubbleGum::addComponent error in "' + t + '".IS_SUPPORTED - it should be a function which returns true/false'), !0) : i
                    }
                }]), t
            }(o);
        f.EVENTS = {
            DOM_COMPONENTS_MOUNTED: "DOM_COMPONENTS_MOUNTED"
        }, t.exports = f
    }, {
        "./ComponentMap": 48,
        "@marcom/ac-event-emitter-micro": 4,
        "@marcom/anim-system": 29,
        "@marcom/anim-system/Model/AnimSystemModel": 34,
        "@marcom/delayed-initializer": 61
    }],
    48: [function(e, t, r) {
        "use strict";
        t.exports = {
            BaseComponent: e("./BaseComponent")
        }
    }, {
        "./BaseComponent": 46
    }],
    49: [function(e, t, r) {
        "use strict";

        function i(e) {
            e = e || {}, s.call(this), this.id = o.getNewID(), this.executor = e.executor || a, this._reset(), this._willRun = !1, this._didDestroy = !1
        }
        var n, s = e("@marcom/ac-event-emitter-micro").EventEmitterMicro,
            a = e("@marcom/ac-raf-executor/sharedRAFExecutorInstance"),
            o = e("@marcom/ac-raf-emitter-id-generator/sharedRAFEmitterIDGeneratorInstance");
        n = i.prototype = Object.create(s.prototype), n.run = function() {
            return this._willRun || (this._willRun = !0), this._subscribe()
        }, n.cancel = function() {
            this._unsubscribe(), this._willRun && (this._willRun = !1), this._reset()
        }, n.destroy = function() {
            var e = this.willRun();
            return this.cancel(), this.executor = null, s.prototype.destroy.call(this), this._didDestroy = !0, e
        }, n.willRun = function() {
            return this._willRun
        }, n.isRunning = function() {
            return this._isRunning
        }, n._subscribe = function() {
            return this.executor.subscribe(this)
        }, n._unsubscribe = function() {
            return this.executor.unsubscribe(this)
        }, n._onAnimationFrameStart = function(e) {
            this._isRunning = !0, this._willRun = !1, this._didEmitFrameData || (this._didEmitFrameData = !0, this.trigger("start", e))
        }, n._onAnimationFrameEnd = function(e) {
            this._willRun || (this.trigger("stop", e), this._reset())
        }, n._reset = function() {
            this._didEmitFrameData = !1, this._isRunning = !1
        }, t.exports = i
    }, {
        "@marcom/ac-event-emitter-micro": 4,
        "@marcom/ac-raf-emitter-id-generator/sharedRAFEmitterIDGeneratorInstance": 6,
        "@marcom/ac-raf-executor/sharedRAFExecutorInstance": 20
    }],
    50: [function(e, t, r) {
        "use strict";
        var i = e("./SingleCallRAFEmitter"),
            n = function(e) {
                this.rafEmitter = new i, this.rafEmitter.on(e, this._onRAFExecuted.bind(this)), this.requestAnimationFrame = this.requestAnimationFrame.bind(this), this.cancelAnimationFrame = this.cancelAnimationFrame.bind(this), this._frameCallbacks = [], this._nextFrameCallbacks = [], this._currentFrameID = -1, this._cancelFrameIdx = -1, this._frameCallbackLength = 0, this._nextFrameCallbacksLength = 0, this._frameCallbackIteration = 0
            },
            s = n.prototype;
        s.requestAnimationFrame = function(e) {
            return this._currentFrameID = this.rafEmitter.run(), this._nextFrameCallbacks.push(this._currentFrameID, e), this._nextFrameCallbacksLength += 2, this._currentFrameID
        }, s.cancelAnimationFrame = function(e) {
            this._cancelFrameIdx = this._nextFrameCallbacks.indexOf(e), this._cancelFrameIdx !== -1 && (this._nextFrameCallbacks.splice(this._cancelFrameIdx, 2), this._nextFrameCallbacksLength -= 2, 0 === this._nextFrameCallbacksLength && this.rafEmitter.cancel())
        }, s._onRAFExecuted = function(e) {
            for (this._frameCallbacks = this._nextFrameCallbacks, this._frameCallbackLength = this._nextFrameCallbacksLength, this._nextFrameCallbacks = [], this._nextFrameCallbacksLength = 0, this._frameCallbackIteration = 0; this._frameCallbackIteration < this._frameCallbackLength; this._frameCallbackIteration += 2) this._frameCallbacks[this._frameCallbackIteration + 1](e.time, e)
        }, t.exports = n
    }, {
        "./SingleCallRAFEmitter": 52
    }],
    51: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterface"),
            n = function() {
                this.events = {}
            },
            s = n.prototype;
        s.requestAnimationFrame = function(e) {
            return this.events[e] || (this.events[e] = new i(e)), this.events[e].requestAnimationFrame
        }, s.cancelAnimationFrame = function(e) {
            return this.events[e] || (this.events[e] = new i(e)), this.events[e].cancelAnimationFrame
        }, t.exports = new n
    }, {
        "./RAFInterface": 50
    }],
    52: [function(e, t, r) {
        "use strict";
        var i = e("./RAFEmitter"),
            n = function(e) {
                i.call(this, e)
            },
            s = n.prototype = Object.create(i.prototype);
        s._subscribe = function() {
            return this.executor.subscribe(this, !0)
        }, t.exports = n
    }, {
        "./RAFEmitter": 49
    }],
    53: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterfaceController");
        t.exports = i.requestAnimationFrame("draw")
    }, {
        "./RAFInterfaceController": 51
    }],
    54: [function(e, t, r) {
        "use strict";
        var i = e("./RAFInterfaceController");
        t.exports = i.requestAnimationFrame("update")
    }, {
        "./RAFInterfaceController": 51
    }],
    55: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = e("@marcom/ac-raf-emitter/update"),
            a = e("@marcom/ac-raf-emitter/draw"),
            o = e("./private/afterOptionalPromise"),
            l = e("./private/ensureFunctionOrNull"),
            c = e("./private/sequence"),
            u = e("./private/clamp"),
            h = function() {
                function e(t) {
                    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    if (i(this, e), "number" != typeof t || !isFinite(t)) throw new TypeError('Clip duration must be a finite number; got "' + t + '"');
                    "function" == typeof r && (r = {
                        draw: r
                    }), this.ease = l(r.ease), this.update = l(r.update), this.draw = r.draw, this.prepare = l(r.prepare), this.finish = l(r.finish), this._duration = 1e3 * t, this._startTime = null, this._isPrepared = !1, this._promise = null, this._isPlaying = !1
                }
                return n(e, [{
                    key: "_run",
                    value: function(e, t) {
                        var r = this;
                        this.lastFrameTime = Date.now(), null === this._startTime && (this._startTime = this.lastFrameTime);
                        var i = this.easedProgress;
                        this.update && s(function() {
                            return r._isPlaying && r.update(i)
                        }), a(function() {
                            r._isPlaying && (r.draw(i), r.isComplete ? c(a, [r.finish, t]) : r._run(r, t))
                        })
                    }
                }, {
                    key: "play",
                    value: function() {
                        var e = this;
                        if ("function" != typeof this.draw) throw new Error('Clip must be given a "draw" function as an option or have its "draw" method overriden.');
                        return this._isPlaying = !0, this._promise ? this._promise : (this._promise = new Promise(function(t, r) {
                            !e._isPrepared && e.prepare ? (e._isPrepared = !0, a(function() {
                                return o(e.prepare(), function() {
                                    e._run(e, t)
                                })
                            })) : e._run(e, t)
                        }), this._promise)
                    }
                }, {
                    key: "destroy",
                    value: function() {
                        this._isPlaying = !1, this.draw = this.finish = this.update = null
                    }
                }, {
                    key: "isReversed",
                    get: function() {
                        return this._duration < 0
                    }
                }, {
                    key: "isComplete",
                    get: function() {
                        var e = this.progress;
                        return !this.isReversed && e >= 1 || this.isReversed && e <= 0
                    }
                }, {
                    key: "progress",
                    get: function() {
                        if (0 === this._duration) return 1;
                        var e = (this.lastFrameTime - this._startTime) / this._duration;
                        return this.isReversed && (e = 1 + e), u(e, 0, 1)
                    }
                }, {
                    key: "easedProgress",
                    get: function() {
                        return this.ease ? this.ease(this.progress) : this.progress
                    }
                }], [{
                    key: "play",
                    value: function() {
                        return (new(Function.prototype.bind.apply(this, [null].concat(Array.prototype.slice.call(arguments))))).play()
                    }
                }]), e
            }();
        t.exports = h
    }, {
        "./private/afterOptionalPromise": 56,
        "./private/clamp": 57,
        "./private/ensureFunctionOrNull": 58,
        "./private/sequence": 59,
        "@marcom/ac-raf-emitter/draw": 53,
        "@marcom/ac-raf-emitter/update": 54
    }],
    56: [function(e, t, r) {
        "use strict";
        t.exports = function(e, t) {
            e instanceof Promise ? e.then(t) : t()
        }
    }, {}],
    57: [function(e, t, r) {
        "use strict";
        t.exports = function(e, t, r) {
            return Math.min(Math.max(e, t), r)
        }
    }, {}],
    58: [function(e, t, r) {
        "use strict";
        t.exports = function(e) {
            return "function" == typeof e ? e : null
        }
    }, {}],
    59: [function(e, t, r) {
        "use strict";
        t.exports = function(e, t) {
            function r() {
                var s = t[n];
                "function" == typeof s && e(t[n]), n++, n < i && r()
            }
            var i = t.length,
                n = 0;
            r()
        }
    }, {}],
    60: [function(e, t, r) {
        "use strict";
        var i = {
                create: e("gl-mat4/create"),
                invert: e("gl-mat4/invert"),
                clone: e("gl-mat4/clone"),
                transpose: e("gl-mat4/transpose")
            },
            n = {
                create: e("gl-vec3/create"),
                dot: e("gl-vec3/dot"),
                normalize: e("gl-vec3/normalize"),
                length: e("gl-vec3/length"),
                cross: e("gl-vec3/cross"),
                fromValues: e("gl-vec3/fromValues")
            },
            s = {
                create: e("gl-vec4/create"),
                transformMat4: e("gl-vec4/transformMat4"),
                fromValues: e("gl-vec4/fromValues")
            },
            a = (Math.PI / 180, 180 / Math.PI),
            o = 0,
            l = 1,
            c = 3,
            u = 4,
            h = 5,
            m = 7,
            f = 11,
            p = 12,
            d = 13,
            v = 15,
            _ = function(e, t) {
                t = t || !1;
                for (var r = i.clone(e), o = n.create(), l = n.create(), u = n.create(), h = s.create(), p = s.create(), d = (n.create(), 0); d < 16; d++) r[d] /= r[v];
                var _ = i.clone(r);
                _[c] = 0, _[m] = 0, _[f] = 0, _[v] = 1;
                var E = (r[3], r[7], r[11], r[12]),
                    w = r[13],
                    A = r[14],
                    S = (r[15], s.create());
                if (g(r[c]) && g(r[m]) && g(r[f])) h = s.fromValues(0, 0, 0, 1);
                else {
                    S[0] = r[c], S[1] = r[m], S[2] = r[f], S[3] = r[v];
                    var O = i.invert(i.create(), _),
                        k = i.transpose(i.create(), O);
                    h = s.transformMat4(h, S, k)
                }
                o[0] = E, o[1] = w, o[2] = A;
                var x = [n.create(), n.create(), n.create()];
                x[0][0] = r[0], x[0][1] = r[1], x[0][2] = r[2], x[1][0] = r[4], x[1][1] = r[5], x[1][2] = r[6], x[2][0] = r[8], x[2][1] = r[9], x[2][2] = r[10], l[0] = n.length(x[0]), n.normalize(x[0], x[0]), u[0] = n.dot(x[0], x[1]), x[1] = y(x[1], x[0], 1, -u[0]), l[1] = n.length(x[1]), n.normalize(x[1], x[1]), u[0] /= l[1], u[1] = n.dot(x[0], x[2]), x[2] = y(x[2], x[0], 1, -u[1]), u[2] = n.dot(x[1], x[2]), x[2] = y(x[2], x[1], 1, -u[2]), l[2] = n.length(x[2]), n.normalize(x[2], x[2]), u[1] /= l[2], u[2] /= l[2];
                var P = n.cross(n.create(), x[1], x[2]);
                if (n.dot(x[0], P) < 0)
                    for (d = 0; d < 3; d++) l[d] *= -1, x[d][0] *= -1, x[d][1] *= -1, x[d][2] *= -1;
                p[0] = .5 * Math.sqrt(Math.max(1 + x[0][0] - x[1][1] - x[2][2], 0)), p[1] = .5 * Math.sqrt(Math.max(1 - x[0][0] + x[1][1] - x[2][2], 0)), p[2] = .5 * Math.sqrt(Math.max(1 - x[0][0] - x[1][1] + x[2][2], 0)), p[3] = .5 * Math.sqrt(Math.max(1 + x[0][0] + x[1][1] + x[2][2], 0)), x[2][1] > x[1][2] && (p[0] = -p[0]), x[0][2] > x[2][0] && (p[1] = -p[1]), x[1][0] > x[0][1] && (p[2] = -p[2]);
                var C = s.fromValues(p[0], p[1], p[2], 2 * Math.acos(p[3])),
                    T = b(p);
                return t && (u[0] = Math.round(u[0] * a * 100) / 100, u[1] = Math.round(u[1] * a * 100) / 100, u[2] = Math.round(u[2] * a * 100) / 100, T[0] = Math.round(T[0] * a * 100) / 100, T[1] = Math.round(T[1] * a * 100) / 100,
                    T[2] = Math.round(T[2] * a * 100) / 100, C[3] = Math.round(C[3] * a * 100) / 100), {
                    translation: o,
                    scale: l,
                    skew: u,
                    perspective: h,
                    quaternion: p,
                    eulerRotation: T,
                    axisAngle: C
                }
            },
            y = function(e, t, r, i) {
                var s = n.create();
                return s[0] = r * e[0] + i * t[0], s[1] = r * e[1] + i * t[1], s[2] = r * e[2] + i * t[2], s
            },
            b = function(e) {
                var t, r, i, s = e[3] * e[3],
                    a = e[0] * e[0],
                    o = e[1] * e[1],
                    l = e[2] * e[2],
                    c = a + o + l + s,
                    u = e[0] * e[1] + e[2] * e[3];
                return u > .499 * c ? (r = 2 * Math.atan2(e[0], e[3]), i = Math.PI / 2, t = 0, n.fromValues(t, r, i)) : u < -.499 * c ? (r = -2 * Math.atan2(e[0], e[3]), i = -Math.PI / 2, t = 0, n.fromValues(t, r, i)) : (r = Math.atan2(2 * e[1] * e[3] - 2 * e[0] * e[2], a - o - l + s), i = Math.asin(2 * u / c), t = Math.atan2(2 * e[0] * e[3] - 2 * e[1] * e[2], -a + o - l + s), n.fromValues(t, r, i))
            },
            g = function(e) {
                return Math.abs(e) < 1e-4
            },
            E = function(e) {
                var t = String(getComputedStyle(e).transform).trim(),
                    r = i.create();
                if ("none" === t || "" === t) return r;
                var n, s, a = t.slice(0, t.indexOf("("));
                if ("matrix3d" === a)
                    for (n = t.slice(9, -1).split(","), s = 0; s < n.length; s++) r[s] = parseFloat(n[s]);
                else {
                    if ("matrix" !== a) throw new TypeError("Invalid Matrix Value");
                    for (n = t.slice(7, -1).split(","), s = n.length; s--;) n[s] = parseFloat(n[s]);
                    r[o] = n[0], r[l] = n[1], r[p] = n[4], r[u] = n[2], r[h] = n[3], r[d] = n[5]
                }
                return r
            };
        t.exports = function(e, t) {
            var r = E(e);
            return _(r, t)
        }
    }, {
        "gl-mat4/clone": 69,
        "gl-mat4/create": 70,
        "gl-mat4/invert": 71,
        "gl-mat4/transpose": 76,
        "gl-vec3/create": 77,
        "gl-vec3/cross": 78,
        "gl-vec3/dot": 79,
        "gl-vec3/fromValues": 80,
        "gl-vec3/length": 81,
        "gl-vec3/normalize": 82,
        "gl-vec4/create": 83,
        "gl-vec4/fromValues": 84,
        "gl-vec4/transformMat4": 85
    }],
    61: [function(e, t, r) {
        "use strict";
        var i = !1,
            n = !1,
            s = [];
        t.exports = {
            NUMBER_OF_FRAMES_TO_WAIT: 30,
            add: function(e) {
                var t = this;
                if (n && e(), s.push(e), !i) {
                    i = !0;
                    var r = document.documentElement.scrollHeight,
                        a = 0,
                        o = function l() {
                            var e = document.documentElement.scrollHeight;
                            if (r !== e) a = 0;
                            else if (a++, a >= t.NUMBER_OF_FRAMES_TO_WAIT) return void s.forEach(function(e) {
                                return e()
                            });
                            r = e, requestAnimationFrame(l)
                        };
                    requestAnimationFrame(o)
                }
            }
        }
    }, {}],
    62: [function(e, t, r) {
        "use strict";
        t.exports = function(e, t) {
            var r;
            return t ? (r = e.getBoundingClientRect(), {
                width: r.width,
                height: r.height
            }) : {
                width: e.offsetWidth,
                height: e.offsetHeight
            }
        }
    }, {}],
    63: [function(e, t, r) {
        "use strict";
        var i = e("./getDimensions");
        t.exports = function(e, t) {
            var r, n, s, a, o, l, c;
            return t ? (r = e.getBoundingClientRect(), n = r.top, s = r.left, a = r.width, o = r.height, e.offsetParent && (l = e.offsetParent.getBoundingClientRect(), n -= l.top, s -= l.left)) : (c = i(e, t), n = e.offsetTop, s = e.offsetLeft, a = c.width, o = c.height), {
                top: n,
                right: s + a,
                bottom: n + o,
                left: s
            }
        }
    }, {
        "./getDimensions": 62
    }],
    64: [function(e, t, r) {
        "use strict";
        t.exports = {
            PICTURE_DATA_DOWNLOAD_AREA_KEYFRAME: "data-download-area-keyframe",
            PICTURE_DATA_LAZY: "data-lazy",
            PICTURE_DATA_EMPTY_SOURCE: "data-empty",
            PICTURE_DATA_LOADED: "data-picture-loaded",
            PICTURE_CLASS_LOADED: "loaded"
        }
    }, {}],
    65: [function(e, t, r) {
        "use strict";
        var i = e("../js/Globals").PICTURE_CLASS_LOADED,
            n = e("../js/Globals").PICTURE_DATA_LOADED,
            s = e("../js/Globals").PICTURE_DATA_EMPTY_SOURCE;
        t.exports = function() {
            window.__pictureElementInstancesLoaded = new Map, window.__lp = function(e) {
                var t = e.target.parentElement;
                return t.querySelector("[" + s + "]") ? void e.stopImmediatePropagation() : (t.classList.add("" + i), t.setAttribute("" + n, ""), window.__pictureElementInstancesLoaded.set(t.id, t), void(e.target.onload = null))
            }
        }()
    }, {
        "../js/Globals": 64
    }],
    66: [function(e, t, r) {
        "use strict";

        function i(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        var n = function() {
                function e(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var i = t[r];
                        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
                    }
                }
                return function(t, r, i) {
                    return r && e(t.prototype, r), i && e(t, i), t
                }
            }(),
            s = e("../js/Globals").PICTURE_DATA_LAZY,
            a = e("../js/Globals").PICTURE_DATA_EMPTY_SOURCE,
            o = e("../js/Globals").PICTURE_DATA_DOWNLOAD_AREA_KEYFRAME,
            l = function() {
                function e() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    i(this, e), this.options = t, this._init()
                }
                return n(e, [{
                    key: "_init",
                    value: function() {
                        this._pictures = Array.from(document.querySelectorAll("*[" + s + "]")), this.AnimSystem = this._findAnim(), null !== this.AnimSystem && (this._injectSources(), this._addKeyframesToImages(), this._addMethodsToPictures())
                    }
                }, {
                    key: "_addMethodsToPictures",
                    value: function() {
                        var e = this;
                        this._pictures.forEach(function(t) {
                            t.forceLoad = function() {
                                e._downloadImage(t)
                            }
                        })
                    }
                }, {
                    key: "_injectSources",
                    value: function() {
                        this._pictures.forEach(function(e) {
                            var t = e.nextElementSibling;
                            if (t && "NOSCRIPT" === t.nodeName) {
                                var r = e.querySelector("img"),
                                    i = t.textContent,
                                    n = i.match(/<source .+ \/>/g);
                                n && r.insertAdjacentHTML("beforebegin", n.join(""))
                            }
                        })
                    }
                }, {
                    key: "_defineKeyframeOptions",
                    value: function(e) {
                        var t = e.getAttribute(o) || "{}";
                        return Object.assign({}, {
                            start: "t - 200vh",
                            end: "b + 100vh",
                            event: "PictureLazyLoading"
                        }, JSON.parse(t))
                    }
                }, {
                    key: "_addKeyframesToImages",
                    value: function() {
                        var e = this;
                        this._pictures.forEach(function(t) {
                            t.__scrollGroup = e.AnimSystem.getGroupForTarget(document.body), e.AnimSystem.getGroupForTarget(t) && (t.__scrollGroup = e.AnimSystem.getGroupForTarget(t));
                            var r = e._defineKeyframeOptions(t),
                                i = t.__scrollGroup.addKeyframe(t, r);
                            i.controller.once("PictureLazyLoading:enter", function() {
                                e._imageIsInLoadRange(t)
                            })
                        })
                    }
                }, {
                    key: "_imageIsInLoadRange",
                    value: function(e) {
                        var t = e.querySelector("img");
                        t && this._downloadImage(e)
                    }
                }, {
                    key: "_downloadImage",
                    value: function(e) {
                        var t = e.querySelector("[" + a + "]");
                        t && e.removeChild(t)
                    }
                }, {
                    key: "_findAnim",
                    value: function() {
                        var e = Array.from(document.querySelectorAll("[data-anim-group],[data-anim-scroll-group],[data-anim-time-group]"));
                        return e.map(function(e) {
                            return e._animInfo ? e._animInfo.group : null
                        }).filter(function(e) {
                            return null !== e
                        }), e[0] && e[0]._animInfo ? e[0]._animInfo.group.anim : (console.error("PictureLazyLoading: AnimSystem not found, please initialize anim before instantiating"), null)
                    }
                }]), e
            }();
        t.exports = l
    }, {
        "../js/Globals": 64
    }],
    67: [function(e, t, r) {
        "use strict";
        var i = e("./PictureLazyLoading"),
            n = e("./PictureHead");
        t.exports = {
            PictureLazyLoading: i,
            PictureHead: n
        }
    }, {
        "./PictureHead": 65,
        "./PictureLazyLoading": 66
    }],
    68: [function(e, t, r) {
        "use strict";
        t.exports = {
            lerp: function(e, t, r) {
                return t + (r - t) * e
            },
            map: function(e, t, r, i, n) {
                return i + (n - i) * (e - t) / (r - t)
            },
            mapClamp: function(e, t, r, i, n) {
                var s = i + (n - i) * (e - t) / (r - t);
                return Math.max(i, Math.min(n, s))
            },
            norm: function(e, t, r) {
                return (e - t) / (r - t)
            },
            clamp: function(e, t, r) {
                return Math.max(t, Math.min(r, e))
            },
            randFloat: function(e, t) {
                return Math.random() * (t - e) + e
            },
            randInt: function(e, t) {
                return Math.floor(Math.random() * (t - e) + e)
            }
        }
    }, {}],
    69: [function(e, t, r) {
        function i(e) {
            var t = new Float32Array(16);
            return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4], t[5] = e[5], t[6] = e[6], t[7] = e[7], t[8] = e[8], t[9] = e[9], t[10] = e[10], t[11] = e[11], t[12] = e[12], t[13] = e[13], t[14] = e[14], t[15] = e[15], t
        }
        t.exports = i
    }, {}],
    70: [function(e, t, r) {
        function i() {
            var e = new Float32Array(16);
            return e[0] = 1, e[1] = 0, e[2] = 0, e[3] = 0, e[4] = 0, e[5] = 1, e[6] = 0, e[7] = 0, e[8] = 0, e[9] = 0, e[10] = 1, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, e
        }
        t.exports = i
    }, {}],
    71: [function(e, t, r) {
        function i(e, t) {
            var r = t[0],
                i = t[1],
                n = t[2],
                s = t[3],
                a = t[4],
                o = t[5],
                l = t[6],
                c = t[7],
                u = t[8],
                h = t[9],
                m = t[10],
                f = t[11],
                p = t[12],
                d = t[13],
                v = t[14],
                _ = t[15],
                y = r * o - i * a,
                b = r * l - n * a,
                g = r * c - s * a,
                E = i * l - n * o,
                w = i * c - s * o,
                A = n * c - s * l,
                S = u * d - h * p,
                O = u * v - m * p,
                k = u * _ - f * p,
                x = h * v - m * d,
                P = h * _ - f * d,
                C = m * _ - f * v,
                T = y * C - b * P + g * x + E * k - w * O + A * S;
            return T ? (T = 1 / T, e[0] = (o * C - l * P + c * x) * T, e[1] = (n * P - i * C - s * x) * T, e[2] = (d * A - v * w + _ * E) * T, e[3] = (m * w - h * A - f * E) * T, e[4] = (l * k - a * C - c * O) * T, e[5] = (r * C - n * k + s * O) * T, e[6] = (v * g - p * A - _ * b) * T, e[7] = (u * A - m * g + f * b) * T, e[8] = (a * P - o * k + c * S) * T, e[9] = (i * k - r * P - s * S) * T, e[10] = (p * w - d * g + _ * y) * T, e[11] = (h * g - u * w - f * y) * T, e[12] = (o * O - a * x - l * S) * T, e[13] = (r * x - i * O + n * S) * T, e[14] = (d * b - p * E - v * y) * T, e[15] = (u * E - h * b + m * y) * T, e) : null
        }
        t.exports = i
    }, {}],
    72: [function(e, t, r) {
        function i(e, t, r) {
            var i = Math.sin(r),
                n = Math.cos(r),
                s = t[4],
                a = t[5],
                o = t[6],
                l = t[7],
                c = t[8],
                u = t[9],
                h = t[10],
                m = t[11];
            return t !== e && (e[0] = t[0], e[1] = t[1], e[2] = t[2], e[3] = t[3], e[12] = t[12], e[13] = t[13], e[14] = t[14], e[15] = t[15]), e[4] = s * n + c * i, e[5] = a * n + u * i, e[6] = o * n + h * i, e[7] = l * n + m * i, e[8] = c * n - s * i, e[9] = u * n - a * i, e[10] = h * n - o * i, e[11] = m * n - l * i, e
        }
        t.exports = i
    }, {}],
    73: [function(e, t, r) {
        function i(e, t, r) {
            var i = Math.sin(r),
                n = Math.cos(r),
                s = t[0],
                a = t[1],
                o = t[2],
                l = t[3],
                c = t[8],
                u = t[9],
                h = t[10],
                m = t[11];
            return t !== e && (e[4] = t[4], e[5] = t[5], e[6] = t[6], e[7] = t[7], e[12] = t[12], e[13] = t[13], e[14] = t[14], e[15] = t[15]), e[0] = s * n - c * i, e[1] = a * n - u * i, e[2] = o * n - h * i, e[3] = l * n - m * i, e[8] = s * i + c * n, e[9] = a * i + u * n, e[10] = o * i + h * n, e[11] = l * i + m * n, e
        }
        t.exports = i
    }, {}],
    74: [function(e, t, r) {
        function i(e, t, r) {
            var i = Math.sin(r),
                n = Math.cos(r),
                s = t[0],
                a = t[1],
                o = t[2],
                l = t[3],
                c = t[4],
                u = t[5],
                h = t[6],
                m = t[7];
            return t !== e && (e[8] = t[8], e[9] = t[9], e[10] = t[10], e[11] = t[11], e[12] = t[12], e[13] = t[13], e[14] = t[14], e[15] = t[15]), e[0] = s * n + c * i, e[1] = a * n + u * i, e[2] = o * n + h * i, e[3] = l * n + m * i, e[4] = c * n - s * i, e[5] = u * n - a * i, e[6] = h * n - o * i, e[7] = m * n - l * i, e
        }
        t.exports = i
    }, {}],
    75: [function(e, t, r) {
        function i(e, t, r) {
            var i = r[0],
                n = r[1],
                s = r[2];
            return e[0] = t[0] * i, e[1] = t[1] * i, e[2] = t[2] * i, e[3] = t[3] * i, e[4] = t[4] * n, e[5] = t[5] * n, e[6] = t[6] * n, e[7] = t[7] * n, e[8] = t[8] * s, e[9] = t[9] * s, e[10] = t[10] * s, e[11] = t[11] * s, e[12] = t[12], e[13] = t[13], e[14] = t[14], e[15] = t[15], e
        }
        t.exports = i
    }, {}],
    76: [function(e, t, r) {
        function i(e, t) {
            if (e === t) {
                var r = t[1],
                    i = t[2],
                    n = t[3],
                    s = t[6],
                    a = t[7],
                    o = t[11];
                e[1] = t[4], e[2] = t[8], e[3] = t[12], e[4] = r, e[6] = t[9], e[7] = t[13], e[8] = i, e[9] = s, e[11] = t[14], e[12] = n, e[13] = a, e[14] = o
            } else e[0] = t[0], e[1] = t[4], e[2] = t[8], e[3] = t[12], e[4] = t[1], e[5] = t[5], e[6] = t[9], e[7] = t[13], e[8] = t[2], e[9] = t[6], e[10] = t[10], e[11] = t[14], e[12] = t[3], e[13] = t[7], e[14] = t[11], e[15] = t[15];
            return e
        }
        t.exports = i
    }, {}],
    77: [function(e, t, r) {
        function i() {
            var e = new Float32Array(3);
            return e[0] = 0, e[1] = 0, e[2] = 0, e
        }
        t.exports = i
    }, {}],
    78: [function(e, t, r) {
        function i(e, t, r) {
            var i = t[0],
                n = t[1],
                s = t[2],
                a = r[0],
                o = r[1],
                l = r[2];
            return e[0] = n * l - s * o, e[1] = s * a - i * l, e[2] = i * o - n * a, e
        }
        t.exports = i
    }, {}],
    79: [function(e, t, r) {
        function i(e, t) {
            return e[0] * t[0] + e[1] * t[1] + e[2] * t[2]
        }
        t.exports = i
    }, {}],
    80: [function(e, t, r) {
        function i(e, t, r) {
            var i = new Float32Array(3);
            return i[0] = e, i[1] = t, i[2] = r, i
        }
        t.exports = i
    }, {}],
    81: [function(e, t, r) {
        function i(e) {
            var t = e[0],
                r = e[1],
                i = e[2];
            return Math.sqrt(t * t + r * r + i * i)
        }
        t.exports = i
    }, {}],
    82: [function(e, t, r) {
        function i(e, t) {
            var r = t[0],
                i = t[1],
                n = t[2],
                s = r * r + i * i + n * n;
            return s > 0 && (s = 1 / Math.sqrt(s), e[0] = t[0] * s, e[1] = t[1] * s, e[2] = t[2] * s), e
        }
        t.exports = i
    }, {}],
    83: [function(e, t, r) {
        function i() {
            var e = new Float32Array(4);
            return e[0] = 0, e[1] = 0, e[2] = 0, e[3] = 0, e
        }
        t.exports = i
    }, {}],
    84: [function(e, t, r) {
        function i(e, t, r, i) {
            var n = new Float32Array(4);
            return n[0] = e, n[1] = t, n[2] = r, n[3] = i, n
        }
        t.exports = i
    }, {}],
    85: [function(e, t, r) {
        function i(e, t, r) {
            var i = t[0],
                n = t[1],
                s = t[2],
                a = t[3];
            return e[0] = r[0] * i + r[4] * n + r[8] * s + r[12] * a, e[1] = r[1] * i + r[5] * n + r[9] * s + r[13] * a, e[2] = r[2] * i + r[6] * n + r[10] * s + r[14] * a, e[3] = r[3] * i + r[7] * n + r[11] * s + r[15] * a, e
        }
        t.exports = i
    }, {}],
    86: [function(e, t, r) {
        "use strict";
        var i = (e("@marcom/ac-chapternav"), e("@marcom/anim-system")),
            n = e("@marcom/bubble-gum"),
            s = e("@marcom/bubble-gum/ComponentMap"),
            a = e("./model/SiteComponentMap"),
            o = e("@marcom/anim-lazy-image/AnimLazyImage"),
            l = e("@marcom/ac-accessibility/TextZoom"),
            c = e("@marcom/picture-element").PictureLazyLoading,
            u = {
                initialize: function() {
                    Object.assign(s, a), i.model.BREAKPOINTS = [{
                        name: "S",
                        mediaQuery: "only screen and (max-width: 734px)"
                    }, {
                        name: "M",
                        mediaQuery: "only screen and (max-width: 1068px)"
                    }, {
                        name: "L",
                        mediaQuery: "only screen and (min-width: 1441px)"
                    }, {
                        name: "L",
                        mediaQuery: "only screen and (min-width: 1069px)"
                    }];
                    var e = document.querySelector(".main"),
                        t = new n(e);
                    t.anim.on(i.model.EVENTS.ON_DOM_KEYFRAMES_CREATED, function() {
                        new o, new c
                    }), l.detect()
                }
            };
        u.initialize()
    }, {
        "./model/SiteComponentMap": 87,
        "@marcom/ac-accessibility/TextZoom": 1,
        "@marcom/ac-chapternav": 3,
        "@marcom/anim-lazy-image/AnimLazyImage": 27,
        "@marcom/anim-system": 29,
        "@marcom/bubble-gum": 47,
        "@marcom/bubble-gum/ComponentMap": 48,
        "@marcom/picture-element": 67
    }],
    87: [function(e, t, r) {
        "use strict";
        t.exports = {}
    }, {}]
}, {}, [86]);